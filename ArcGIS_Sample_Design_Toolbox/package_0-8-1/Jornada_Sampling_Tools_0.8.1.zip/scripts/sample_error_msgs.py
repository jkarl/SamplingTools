# Sample_Error_Msgs.py
# file containing error messages and other constants defined for the sampling functions

import win32com.client, sys, os, arcgisscripting, math, random, time

gp = arcgisscripting.create()

#--------------------------------------------------------------------------
#Custom Exceptions
#    See http://www.python.org/doc/current/tut/node10.html for more
#    information about custom exceptions
#--------------------------------------------------------------------------
class ReportError(Exception):
    """Send an error message to the application history window."""
    def __init__(self, message):
        self.message = message
    def __str__(self):
        gp.AddError(self.message)
	print self.message
        return repr(self.message)

#--------------------------------------------------------------------------
# Setup error messages
#--------------------------------------------------------------------------
ReportError = "CustomErrorHandler"
msgInputDNE = "The following input layer does not exist or cannot be found: "
msgAttributeDNE = "Could not find the attribute defining the sampling probabilities in the sampling units layer."
msgOutPathDNE = "Output directory does not exist."
msgOutputExists = "Output feature layer already exists and cannot be deleted."
msgTempExists = "A necessary temporary file exists and cannot be deleted."
msgExtentNotPoly = "Extent layer must be a polygon layer."
msgExtentNotProjected = "Extent layer must be in a projected coordinate system and have the coordinate system defined to use the point density option."
msgSampSizeError = "An error was encountered in calculating the sample size from the density requirement."
msgInvalidDistanceType = "An invalid density/point spacing type was specified."
msgSpacingTooBig = "Point spacing is too large for the input layer extent."
msgErrorWritingOutput = "Error in writing output file"
msgLicenseError = "Spatial Analyst extension not available"
msgAttributeTypeWrong = "The attribute specified for the selection probabilities is not a numeric field."
msgInvalidNtype = "Desired sample size units are invalid."

