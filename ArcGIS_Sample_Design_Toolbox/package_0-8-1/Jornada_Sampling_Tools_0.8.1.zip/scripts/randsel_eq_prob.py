#-----------------------------------------------------------------------------
# Name: randsel_uneq_prob.py
# Author: Jason Karl
# Version: ArcGIS v9.2+
# Date: April 2, 2010
#-----------------------------------------------------------------------------
# Purpose:
# This script draws random samples from within the input layers according to
# the following properties:
# 1. selection probabilities are equal 
# 2. Random selections are made of features from an input feature class
# 3. The number of points to be selected can be expressed in absolute terms or as a density
#-----------------------------------------------------------------------------
# Inputs/Arguments
# samp_units = A vector layer of the sample frame
#            where each feature is a sampling unit. 
# n = number of samples desired
# n_type = whether n is expressed in absolute terms or as a density in # per ac or # per ha.
#          acceptable values are: "Absolute", "Density per hectare", and "Density per acre."
# outfeat = name of output point feature class that will contain locations and IDs of the
#           random sample realization.
#-----------------------------------------------------------------------------

#-----------------------------------------------------------------------------
# Libraries & initializaton
#-----------------------------------------------------------------------------
import win32com.client, sys, os, arcgisscripting, math, random
from sample_functions import *
from sample_error_msgs import *
from version_info import *

gp = arcgisscripting.create()

print version_info
gp.AddMessage(version_info)

# read arguments
samp_units = sys.argv[1]
n = float(sys.argv[2])
n_type = sys.argv[3]
outfeat = sys.argv[4]   
    
try:

    #-----------------------------------------------------------------------------
    # Finish initializing the work environment
    #-----------------------------------------------------------------------------
    
    # load other required toolboxes
    gp.AddToolbox(os.environ['ARCGISHOME']+"ArcToolbox/Toolboxes/Data Management Tools.tbx")
    gp.AddToolbox(os.environ['ARCGISHOME']+"ArcToolbox/Toolboxes/Conversion Tools.tbx")
    
    #-----------------------------------------------------------------------------
    # validate arguments and initialize
    #-----------------------------------------------------------------------------
    gp.AddMessage("Checking arguments")
    print("Checking arguments")

    if samp_units == "#":
        samp_units = "C:\\Users\\jasokarl\\Documents\\Multi_Scale_Assessment\\analysis\\castle_creek_scale\\Scale50.shp"
    if not gp.exists(samp_units):
        raise ReportError, (msgInputDNE + samp_units)    
           
    if n == "#":
        n = 20
    
    if n_type == "#":
        n_type = "total number of points"
    if not n_type.lower() in ["points per acre", "points per hectare", "total number of points", "1 point per x acres", "1 point per x hectares"]:
        raise ReportError, msgInvalidNtype
        
    if outfeat == "#":
        outfeat = "C:\\Users\\jasokarl\\Documents\\My Dropbox\\sampling_tools\\test_eqsel1.shp"
    outwork = os.path.split(outfeat)[0]
    outfeat = os.path.split(outfeat)[1]
    if not os.path.exists(outwork):
        raise ReportError, msgOutPathDNE
        
    #Set workspace
    gp.Workspace = outwork
    gp.OverwriteOutput = True

    # Check output layer and delete if exists
    if not check_exist(outfeat): raise ReportError, msgOutputExists

    print("Creating Sample")
    gp.AddMessage("Creating Sample")
    
    #-----------------------------------------------------------------------------
    # Polygon inc_prob layer - enumerate features and inc probs
    #-----------------------------------------------------------------------------
    temp = getIDandProbLists(samp_units, "#")
    if temp[0] == -1: raise ReportError, "error enumerating features and inclusion probabilities"
    IDlist = temp[0]
    Pi = temp[1]
    
    # Calculate selection probabilities
    Pi = calcSelProbs(IDlist, Pi, "#")

    # now pair up the IDs and selection probabilities
    c = zip(IDlist, Pi)
    print len(IDlist)
    print len(Pi)
    print c[0:25]
    
    # randomize the order of the lists
    random.shuffle(c)
    print c[0:25]
    
    #---------------------------------------------------------------------------
    # Calculate number of samples if a density option was selected
    #---------------------------------------------------------------------------
    n = int(calc_num_samps(samp_units, "shapefile", n_type, n, 1)) #function requires a minimum sep distance, supply 1
    gp.AddMessage(str(n))
    if n < 0: raise ReportError, msgSampSizeError
    if n > len(IDlist): raise ReportError, msgSampSizeError
    
    #---------------------------------------------------------------------------
    # Select samples from array
    #---------------------------------------------------------------------------
    temp = selectSamples("#", c, n)
    if temp[0] == -1: raise ReportError, "error encountered in selecting random samples."
    Selected = temp[0]
    selPi = temp[1]
    
    print(Selected)
    print(len(Selected))
    
    print("almost done")

    #-----------------------------------------------------------------------------
    # Select the random samples from the input shapefile and write them to the output shapefile
    #-----------------------------------------------------------------------------
    #Pull selected units from the file and write to new point shapefile
    if createSelOutput(Selected, selPi, samp_units, gp.Workspace+"\\"+outfeat):
        print "Finished!"
        gp.AddMessage("Finished")
    else: 
        print "error encountered"
        print gp.GetMessages()
    
    # delete temporary datasets
    if not check_exist(samp_units): raise ReportError, "error deleting temporary dataset " + samp_units
    
    
#-----------------------------------------------------------------------------
# Error handling
#-----------------------------------------------------------------------------
except ReportError, ErrorMsg: #deals with trapped errors
    gp.AddError(ErrorMsg)
    print ErrorMsg
    gp.AddError("Quitting...")
    print "Quitting..."
except: # deals with untrapped errors
    gp.AddMessage(gp.GetMessages(2))
    print(gp.GetMessages(2))
