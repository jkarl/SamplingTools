# version_info.py

toolVersion = "0.8"
relDate = "Jan 4, 2011"

version_info = "\n\nJornada Sampling Tools, version " + toolVersion + ". \nReleased " + relDate + ". \nFor more information, visit \nhttp://www.landscapetoolbox.org/assessment_and_monitoring/sample_design_tools\nReport problems or bugs at: \nhttp://abstracts.rangelandmethods.org/doku.php/bug_reporting\n\n"