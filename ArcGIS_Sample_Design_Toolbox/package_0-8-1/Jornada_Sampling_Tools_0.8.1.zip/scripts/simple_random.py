#-----------------------------------------------------------------------------
# Name: simple_random.py
# Author: Jason Karl
# Version: ArcGIS v9.2+
# Date: April 26, 2010
#-----------------------------------------------------------------------------
# Purpose:
# This script creates a set of random points from within an input layers' extent according to
# the following properties:
# 1. selection probabilities are equal
# 2. procedure follows simple random selection
# 3. minimum distance separating locations can be specified
# 4. number of samples can be specified in absolute terms or as a density
#-----------------------------------------------------------------------------
# Inputs/Arguments
# extent_layer = feature class specifying extent of sample locations
# msd = minimum distance separating random locations
# dist_type = whether minimum distance is maximum plot dimension or some other desired minimum distance
# n = number of samples desired
# n_type = whether n is expressed in absolute terms or as a density in # per ac or # per ha.
#          acceptable values are: "Absolute", "Density per hectare", and "Density per acre."
# outfeat = name of output point feature class that will contain locations and IDs of the
#           random sample realization.
#-----------------------------------------------------------------------------

#-----------------------------------------------------------------------------
# Libraries & initializaton
#-----------------------------------------------------------------------------
import win32com.client, sys, os, arcgisscripting, math, random
from sample_functions import *
from sample_error_msgs import *
from version_info import *

gp = arcgisscripting.create()

print version_info
gp.AddMessage(version_info)

# read arguments
extent_layer = sys.argv[1]
distunits = sys.argv[2]
n = float(sys.argv[3])
n_type = sys.argv[4]
outfeat = sys.argv[5]   

gp.AddMessage(distunits)

try:
    
#-----------------------------------------------------------------------------
# Finish initializing the work environment
#-----------------------------------------------------------------------------

    # load other required toolboxes
    gp.AddToolbox(os.environ['ARCGISHOME']+"ArcToolbox/Toolboxes/Data Management Tools.tbx")
    gp.AddToolbox(os.environ['ARCGISHOME']+"ArcToolbox/Toolboxes/Conversion Tools.tbx")    

    
#-----------------------------------------------------------------------------
# validate arguments and initialize
#-----------------------------------------------------------------------------
    gp.AddMessage("Checking arguments")
    print("Checking arguments")

    if extent_layer == "#":
        extent_layer = "C:\\Users\\jasokarl\\Documents\\Multi_Scale_Assessment\\geodata\\Castle_Creek\\castle_Creek_study_boundary.shp"
    if not gp.exists(extent_layer):
        raise ReportError, (msgInputDNE + samp_frame)
    # check to see if it is a polygon layer
    desc = gp.Describe(extent_layer)
    st = desc.ShapeType
    if not st.lower() == "polygon": raise ReportError, msgExtentNotPoly
    # check to see if it is projected
    SR = desc.SpatialReference
    if not SR.Type == "Projected": raise ReportError, msgExtentNotProjected

    # parse out the distance from the units and convert to meters
    if distunits == "#":
        distunits = "200 Meters"
    h = distunits.split()
    dist = float(h[0])
    units = h[1]
    msd = convert2meters(dist,units)
    
    gp.AddMessage(n_type.lower)
    if n_type == "#":
        n_type = "points per acre"
    if not n_type.lower() in ["points per acre", "points per hectare", "total number of points", "1 point per x acres", "1 point per x hectares"]:
        raise ReportError, msgInvalidNtype
        
    if outfeat == "#":
        outfeat = "C:\\Users\\jasokarl\\Documents\\My Dropbox\\sampling_tools\\test_srs2.shp"
    outwork = os.path.split(outfeat)[0]
    outfeat = os.path.split(outfeat)[1]
    if not os.path.exists(outwork):
        raise ReportError, msgOutPathDNE
        
    #Set workspace
    gp.Workspace = outwork
    gp.OverwriteOutput = True

    # Check output layer and delete if exists
    if not check_exist(outfeat): raise ReportError, msgOutputExists

    print("Creating Sample")
    gp.AddMessage("Creating Sample")
    
#-----------------------------------------------------------------------------
# find full extent of the extent layer
#-----------------------------------------------------------------------------
    extent = desc.extent
    xmin = float(extent.split(" ")[0])
    ymin = float(extent.split(" ")[1])
    xmax = float(extent.split(" ")[2])
    ymax = float(extent.split(" ")[3])
    xdist = xmax-xmin
    ydist = ymax-ymin
    
#-----------------------------------------------------------------------------
# return the xy list for the extent layer
#-----------------------------------------------------------------------------
    xylist = poly2xylist(extent_layer)
            
#-----------------------------------------------------------------------------
# figure out how many samples are needed and check to see if they'll fit in the extent polygon
#-----------------------------------------------------------------------------

    n2 = calc_num_samps(extent_layer, "layer", n_type, n, msd)
    if n2 == -1: raise ReportError, msgSampSizeError
    
#-----------------------------------------------------------------------------
# Create random locations
#-----------------------------------------------------------------------------
    try:
        gp.CreateRandomPoints(outwork, outfeat, extent_layer, "", n2, msd)
        gp.addxy(outfeat)
        gp.addfield(outfeat, "SelProb", "FLOAT", 10, 9)
        selprob = 1.0/(n2)
        gp.CalculateField_management(outfeat, "SelProb", selprob)
        gp.CalculateField_management(outfeat, "CID", "[FID] + 1")
        
    except:
        print gp.GetMessages()
        raise ReportError, msgErrorWritingOutput

    
#-----------------------------------------------------------------------------
# Clean up
#-----------------------------------------------------------------------------
    print "Finished!"


#-----------------------------------------------------------------------------
# Error Handling
#-----------------------------------------------------------------------------
except ReportError, ErrorMsg: #deals with trapped errors
    gp.AddError(ErrorMsg)
    print ErrorMsg
    gp.AddError("Quitting...")
    print "Quitting..."
except: # deals with untrapped errors
    gp.AddMessage(gp.GetMessages(2))
    print(gp.GetMessages(2))
