#-----------------------------------------------------------------------------
# Name: stratified_random_uneq_prob.py
# Author: Jason Karl
# Version: ArcGIS v9.2+
# Date: Jan 10, 2011
#-----------------------------------------------------------------------------
# Purpose:
# This script creates a set of stratified random points from within an input layers' extent according to
# the following properties:
# 1. selection probabilities are unequal
# 2. strata are defined by an attribute in the polygon input layer. points will be randomly generated within each
#    polygon of the stratum layer.
# 3. procedure follows simple random selection within each stratum
# 4. minimum distance separating locations can be specified
# 5. A fixed number of points per stratum can be defined, or the number can vary by stratum
# 4. number of samples per stratum can be specified in absolute terms or as a density
#-----------------------------------------------------------------------------
# Inputs/Arguments
# stratum_layer = feature class specifying extent of sample locations
# stratum_field = field of the input feature set that defines the strata
# sel_prob_surf = raster layer defining the selection probabilities
# distunits = minimum distance separating random locations
# fixed_or_variable = will a fixed number of samples be drawn from each stratum, or will it vary by stratum?
# n = number of samples desired. Conitional on fixed
# n_field = field of the input polygon feature class that defines how many samples will be drawn per stratum.
#           Conditional on variable.
# n_type = whether n is expressed in absolute terms or as a density in # per ac or # per ha.
#          acceptable values are: "Absolute", "Density per hectare", and "Density per acre."
# outfeat = name of output point feature class that will contain locations and IDs of the
#           random sample realization.
#-----------------------------------------------------------------------------

#-----------------------------------------------------------------------------
# Libraries & initializaton
#-----------------------------------------------------------------------------
import win32com.client, sys, os, arcgisscripting, math, random, time
from sample_functions import *
from sample_error_msgs import *
from version_info import *

gp = arcgisscripting.create()


class ReportError(Exception):
    """Send an error message to the application history window."""
    def __init__(self, message):
        self.message = message
    def __str__(self):
        gp.AddError(self.message)
	print self.message
        return repr(self.message)

print version_info
gp.AddMessage(version_info)

# read arguments
stratum_fs = gp.GetParameter(0)
stratum_field = sys.argv[2]
sel_prob_surf = sys.argv[3]
distunits = sys.argv[4]
fixed_or_variable = sys.argv[5]
n = sys.argv[6]
n_field = sys.argv[7]
n_type = sys.argv[8]
outfeat = sys.argv[9]   


try:
    
#-----------------------------------------------------------------------------
# Finish initializing the work environment
#-----------------------------------------------------------------------------

    # check out spatial analyst extension
    if gp.CheckExtension("spatial") == "Available":
        gp.CheckOutExtension("spatial")
    else:
        raise ReportError, msgLicenseError

    # load other required toolboxes
    gp.AddToolbox(os.environ['ARCGISHOME']+"ArcToolbox/Toolboxes/Data Management Tools.tbx")
    gp.AddToolbox(os.environ['ARCGISHOME']+"ArcToolbox/Toolboxes/Spatial Analyst Tools.tbx")
    gp.AddToolbox(os.environ['ARCGISHOME']+"ArcToolbox/Toolboxes/Conversion Tools.tbx")
    gp.AddToolbox(os.environ['ARCGISHOME']+"ArcToolbox/Toolboxes/Analysis Tools.tbx")
    
#-----------------------------------------------------------------------------
# validate arguments and initialize
#-----------------------------------------------------------------------------
    gp.AddMessage("Checking arguments")
    print("Checking arguments")

    if stratum_fs == "#":
        stratum_fs = "C:\\Users\\jasokarl\\Documents\\My Dropbox\sampling_tools\d0.shp"
    if not gp.exists(stratum_fs):
        raise ReportError, (msgInputDNE + stratum_fs)
    # check to see if it is a polygon layer
    desc = gp.Describe(stratum_fs)
    extent = desc.extent
    st = desc.ShapeType
    if not st.lower() == "polygon": raise ReportError, msgExtentNotPoly
    # check to see if it is projected
    SR = desc.SpatialReference
    if not SR.Type == "Projected": raise ReportError, msgExtentNotProjected

    # check to see if the stratum_field exists
    if stratum_field == "#":
        stratum_field = "iObj100ID"
    # check to see if attribute exists and that it's numeric
    if not CheckField(stratum_fs, stratum_field, "categorical"): raise ReportError, msgAttributeDNE    
    
    # Check for existence of probability surface
    if sel_prob_surf == "#":
        sel_prob_surf = "C:\\Users\\jasokarl\\Documents\\My Dropbox\\sampling_tools\\dst_test"
    if not sel_prob_surf == "#":
        if not gp.exists(sel_prob_surf):
            raise ReportError, (msgInputDNE + sel_prob_surf)    
    
    # parse out the distance from the units and convert to meters
    if distunits == "#":
        distunits = "200 Meters"
    h = distunits.split()
    dist = float(h[0])
    units = h[1]
    msd = convert2meters(dist,units)
    
    # check the sample size arguments
    if fixed_or_variable.lower() == "#": fixed_or_variable = "fixed"
    if fixed_or_variable.lower() == "fixed":
        if n == "#": n = float(5)
        else: float(n)
    else:
        if n_field == "#": n_field = "numpoints"
        if not CheckField(stratum_fs, n_field, "numeric"): raise ReportError, msgAttributeDNE
    
    # check the sample size type argument
    if n_type == "#":
        n_type = "total number of points"
    if not n_type.lower() in ["points per acre", "points per hectare", "total number of points", "1 point per x acres", "1 point per x hectares"]:
        raise ReportError, msgInvalidNtype
    
    # get the output feature class name and directory
    if outfeat == "#":
        outfeat = gp.CreateScratchName("strat_rand_uneq_","","shapefile","C:\\Users\\jasokarl\\Documents\\My Dropbox\\sampling_tools")
    outwork = os.path.split(outfeat)[0]
    outfeat = os.path.split(outfeat)[1]
    if not os.path.exists(outwork):
        raise ReportError, msgOutPathDNE
        
    #Set workspace
    gp.Workspace = outwork
    gp.OverwriteOutput = True

    
    #---------------------------------------------------------------------------
    # generate random locations within a study extent
    #---------------------------------------------------------------------------            
    print "Creating random sample. This may take some time for large input layers."
    gp.AddMessage("Creating random sample. This may take some time for large input layers.")        
    
    # create random raster surface with cell size set by msd
    rand_ras = gp.CreateScratchName("grnd","","raster",gp.Workspace)
    if not check_exist(rand_ras): raise ReportError, msgTempExists
    gp.CreateRandomRaster_sa(rand_ras, "", msd, extent)     
    
    # convert raster to point layer (don't really need the random numbers, but this forces a point for each grid cell)
    grid_pts = gp.CreateScratchName("gpts","","shapefile",gp.Workspace)
    if not check_exist(grid_pts): raise ReportError, msgTempExists
    gp.RasterToPoint_conversion(rand_ras, grid_pts, "Value")
    gp.MakeFeatureLayer(grid_pts, "grid_pts")
    
    # find sel probs for each point from sel_prob_surf, or calc equal sample probs
    samp_units = gp.CreateScratchName("su","","shapefile",gp.Workspace)
    if not check_exist(samp_units): raise ReportError, msgTempExists
    sel_probs = gp.CreateScratchName("selprob","","shapefile",gp.Workspace)
    if not check_exist(sel_probs): raise ReportError, msgTempExists
    gp.ExtractValuesToPoints_sa(grid_pts, sel_prob_surf, sel_probs)
    gp.identity_analysis(sel_probs,stratum_fs,samp_units)
    
    prob_attr = "unequal"  # just needs to be something other than default hash.
    name = "RASTERVALU" #name of field with sample probs.

#-----------------------------------------------------------------------------
# set up outfeat feature class
#-----------------------------------------------------------------------------
    outfeat = gp.CreateFeatureClass(outwork, outfeat, "POINT", "#", "#", "#", SR)
    gp.addfield_management(outfeat, "POINT_X", "DOUBLE", "19", "2")
    gp.addfield_management(outfeat, "POINT_Y", "DOUBLE", "19", "2")
    gp.AddField_management(outfeat, "SAMPPROB", "float", "10", "9")
    gp.AddField_management(outfeat, "STRATUM", "TEXT", "255", "254")        
    
#-----------------------------------------------------------------------------
# Dissolve the stratum layer by the stratum field, then start iteration over strata
#-----------------------------------------------------------------------------
    hold = gp.CreateFeatureclass("in_memory", "hold", "POINT", "#", "#", "#", SR)       
    sRows = gp.SearchCursor(stratum_fs)
    sRow = sRows.Next()
    m = 0  
    
    while sRow:
        s = sRow.shape
        stratum = sRow.GetValue(stratum_field)
        if fixed_or_variable.lower() == "variable":
            n = sRow.GetValue(n_field)
        m += 1

#-----------------------------------------------------------------------------
# Select the points corresponding to the stratum
#-----------------------------------------------------------------------------
        qstring = stratum_field + " = " + str(stratum)
        stratum_points = gp.MakeFeatureLayer(samp_units,"stratum_points", " %s " % qstring)
	
#-----------------------------------------------------------------------------
# figure out how many samples are needed and check to see if they'll fit in the extent polygon
#-----------------------------------------------------------------------------
        n2 = calc_num_samps(s, "feature", n_type, float(n), msd)
        if n2 == -1: raise ReportError, msgSampSizeError
    
#-----------------------------------------------------------------------------
# Create random locations
#-----------------------------------------------------------------------------
        try:
            temp = getIDandProbLists(stratum_points, name)
            if temp[0] == -1: raise ReportError, "error enumerating random sampling locations."
            IDlist = temp[0]
            Pi = temp[1]
	    
            #-----------------------------------------------------------------------
                
            # Calculate selection probabilities if none exist
            Pi = calcSelProbs(IDlist, Pi, prob_attr)
        
            # now pair up the IDs and selection probabilities
            c = zip(IDlist, Pi)
            
            # randomize the order of the lists
            random.shuffle(c)
	    
            #---------------------------------------------------------------------------
            # Select samples from array
            #---------------------------------------------------------------------------
            temp = selectSamples(prob_attr, c, n)
	
	    if temp[0] == -1: raise ReportError, "error encountered in selecting random samples."
            z = zip(temp[0],temp[1])  # do some sorting so the points go in according to the feature ID order
            z.sort() 
            Selected, selPi = zip(*z)
            
            #---------------------------------------------------------------------------
            # Add selected points to the master output feature layer
            #---------------------------------------------------------------------------
            if createSelOutput(Selected, selPi, stratum_points, hold):
                print "Selecting "+str(len(Selected))+" locations from Stratum "+str(stratum)
                gp.AddMessage("Selecting "+str(len(Selected))+" locations from Stratum "+str(stratum))
		# now need to append hold to outfeat
		gp.AddField_management(hold, "STRATUM", "TEXT", "255", "254")
		gp.CalculateField_management(hold, "STRATUM", stratum, "PYTHON")
		gp.append_management(hold, outfeat, "NO_TEST")
            else: 
                print "error encountered"
                print gp.GetMessages()
		
        except:
            print gp.GetMessages()
            raise ReportError, msgErrorWritingOutput

            # delete temporary datasets
	if not check_exist(hold): raise ReportError, "error deleting temporary dataset " + hold
        if not check_exist(stratum_points): raise ReportError, "error deleting temporary dataset " + stratum_points
            
        sRow = sRows.Next()
    del sRow
    del sRows

    gp.AddMessage("ok6")
    
#-----------------------------------------------------------------------------
# Finish adding/calculating attributes for the output file
#-----------------------------------------------------------------------------
    
    try:
	gp.AddField_management(outfeat, "pntID", "LONG", "9")
        gp.CalculateField_management(outfeat, "pntID", "[FID] + 1")
        
    except:
        print gp.GetMessages()
        raise ReportError, msgErrorWritingOutput    
    
#-----------------------------------------------------------------------------
# Clean up
#-----------------------------------------------------------------------------
    if not check_exist(hold): raise ReportError, "error deleting temporary dataset " + hold
    if not check_exist(sel_probs): raise ReportError, "error deleting temporary dataset " + sel_probs
    if not check_exist(rand_ras): raise ReportError, "error deleting temporary dataset " + rand_ras
    if not check_exist(grid_pts): raise ReportError, "error deleting temporary dataset " + grid_pts
    if not check_exist(extent): raise ReportError, "error deleting temporary dataset " + extent    
     
    print "Finished!"


#-----------------------------------------------------------------------------
# Error Handling
#-----------------------------------------------------------------------------
except ReportError, ErrorMsg: #deals with trapped errors
    gp.AddError("Quitting...")
    print "Quitting..."
except: # deals with untrapped errors
    gp.AddMessage(gp.GetMessages())
    print(gp.GetMessages())
