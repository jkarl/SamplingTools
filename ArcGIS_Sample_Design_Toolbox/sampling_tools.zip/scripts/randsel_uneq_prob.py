#-----------------------------------------------------------------------------
# Name: randsel_uneq_prob.py
# Author: Jason Karl
# Version: ArcGIS v9.2+
# Date: April 2, 2010
#-----------------------------------------------------------------------------
# Purpose:
# This script draws random samples from within the input layers according to
# the following properties:
# 1. selection probabilities are unequal and defined by an attribute in the input polygon layer
#    Note that the attribute does not need to be expressed as selection probabilities, just a numeric field
# 2. Random selections can be made of features from an input feature class
# 3. The number of points to be selected can be expressed in absolute terms or as a density
#-----------------------------------------------------------------------------
# Inputs/Arguments
# samp_units = A vector layer of the sample frame
#            where each feature is a sampling unit. 
# prob_attr = Conditional on sel_from_layer. Optional. attribute in the samp_units layer that identifies
#             the attribute that contains the inclusions probabilities. If #, assume equal
#	      selection probs.
# n = number of samples desired
# n_type = whether n is expressed in absolute terms or as a density in # per ac or # per ha.
#          acceptable values are: "Absolute", "Density per hectare", and "Density per acre."
# outfeat = name of output point feature class that will contain locations and IDs of the
#           random sample realization.
#-----------------------------------------------------------------------------

#-----------------------------------------------------------------------------
# Libraries & initializaton
#-----------------------------------------------------------------------------
import win32com.client, sys, os, arcgisscripting, math, random
from sample_functions import *
from sample_error_msgs import *
from version_info import *

gp = arcgisscripting.create()

print version_info
gp.AddMessage(version_info)

# read arguments
samp_units_fs = sys.argv[1]
prob_attr = sys.argv[2]
n = sys.argv[3]
n_type = sys.argv[4]
outfeat = sys.argv[5]   
    
try:

    #-----------------------------------------------------------------------------
    # Finish initializing the work environment
    #-----------------------------------------------------------------------------
    
    # load other required toolboxes
    #check version and get install directory
    installD = gp.GetInstallInfo("desktop")
    for key in installD.keys():
        if key == "InstallDir":
            installpath = installD[key]   
    
    # load other required toolboxes
    gp.AddToolbox(installpath+"ArcToolbox\\Toolboxes\\Data Management Tools.tbx")
    gp.AddToolbox(installpath+"ArcToolbox\\Toolboxes\\Conversion Tools.tbx")  
    
    #-----------------------------------------------------------------------------
    # validate arguments and initialize
    #-----------------------------------------------------------------------------
    gp.AddMessage("Checking arguments")
    print("Checking arguments")

    if samp_units_fs == "#":
        samp_units_fs = "C:\\Users\\Jason\\Dropbox\\sampling_tools\\test_samp_units.shp"
    if not gp.exists(samp_units_fs):
        raise ReportError, (msgInputDNE + samp_units_fs)    

    if prob_attr == "#":
        prob_attr = "prob2"
    # check to see if attribute exists and that it's numeric
    ds = gp.Describe(samp_units_fs)
    fields = ds.Fields
    field = fields.next()
    fieldName = False
    fieldtype = False
    while field:
        if field.Name == prob_attr:
            if field.Type.lower() in ["double", "float", "short", "long", "single"]: fieldType = True
            fieldName = True
            break
        field = fields.next()
    if not fieldName:
        raise ReportError, msgAttributeDNE    
    if not fieldType:
        raise ReportError, msgAttributeTypeWrong
           
    if n == "#":
        n = float(20)
    else:
        n = float(n)
    
    if n_type == "#":
        n_type = "total number of points"
    if not n_type.lower() in ["points per acre", "points per hectare", "total number of points", "1 point per x acres", "1 point per x hectares"]:
        raise ReportError, msgInvalidNtype
        
    if outfeat == "#":
        outfeat = "C:\\Users\\Jason\\Dropbox\\sampling_tools\\test_uneq_sel3.shp"
    outwork = os.path.split(outfeat)[0]
    outfeat = os.path.split(outfeat)[1]
    if not os.path.exists(outwork):
        raise ReportError, msgOutPathDNE
        
    #Set workspace
    gp.Workspace = outwork
    gp.OverwriteOutput = True

    # Check output layer and delete if exists
    if not check_exist(outfeat): raise ReportError, msgOutputExists

    print "Creating random sample. This may take some time for large input layers."
    gp.AddMessage("Creating random sample. This may take some time for large input layers.")      
    
    print("Creating Sample")
    gp.AddMessage("Creating Sample")
    
    # because input extent is a feature set, need to convert it to a featureclass
    samp_units = gp.CreateScratchName("s","","shapefile",gp.Workspace)
    gp.CopyFeatures(samp_units_fs, samp_units)

    #-----------------------------------------------------------------------------
    # Polygon inc_prob layer - enumerate features and inc probs
    #-----------------------------------------------------------------------------
    temp = getIDandProbLists(samp_units, prob_attr)
    if temp[0] == -1: raise ReportError, "error enumerating features and inclusion probabilities"
    IDlist = temp[0]
    Pi = temp[1]
        
    # Calculate selection probabilities
    Pi = calcSelProbs(IDlist, Pi, prob_attr)

    # now pair up the IDs and selection probabilities
    c = zip(IDlist, Pi)

    # randomize the order of the lists
    random.shuffle(c)

    #---------------------------------------------------------------------------
    # Calculate number of samples if a density option was selected
    #---------------------------------------------------------------------------
    n = int(calc_num_samps(samp_units, "shapefile", n_type, n, 1)) #function requires a minimum sep distance, supply 1
    gp.AddMessage(str(n))
    if n < 0: raise ReportError, msgSampSizeError
    if n > len(IDlist): raise ReportError, msgSampSizeError
    
    #---------------------------------------------------------------------------
    # Select samples from array
    #---------------------------------------------------------------------------
    temp = selectSamples(prob_attr, c, n)
    if temp[0] == -1: raise ReportError, "error encountered in selecting random samples."
    z = zip(temp[0],temp[1])  # do some sorting so the points go in according to the feature ID order
    z.sort()
    Selected, selPi = zip(*z)
    #Selected = temp[0]
    #selPi = temp[1]
    
    print(Selected)
    print(len(Selected))
    
    print("almost done")

    #-----------------------------------------------------------------------------
    # Select the random samples from the input shapefile and write them to the output shapefile
    #-----------------------------------------------------------------------------
    #Pull selected units from the file and write to new point shapefile
    if createSelOutput(Selected, selPi, samp_units, gp.Workspace+"\\"+outfeat):
        print "Finished!"
        gp.AddMessage("Finished")
    else: 
        print "error encountered"
        print gp.GetMessages()
    
    # delete temporary datasets
    if not check_exist(samp_units): raise ReportError, "error deleting temporary dataset " + samp_units
    
    
#-----------------------------------------------------------------------------
# Error handling
#-----------------------------------------------------------------------------
except ReportError, ErrorMsg: #deals with trapped errors
    gp.AddError("Quitting...")
    print "Quitting..."
except: # deals with untrapped errors
    gp.AddMessage(gp.GetMessages(2))
    print(gp.GetMessages(2))
