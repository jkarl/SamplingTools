#-----------------------------------------------------------------------------
# Name: spatial_balanced.py
# Author: Jason Karl (see acknowledgment below)
# Version: ArcGIS v9.2+
# Date: Oct 17, 2011
#-----------------------------------------------------------------------------
# Acknowledgment:
# This script is a slightly modified and much simplified implementation of the 
# RRQRR spatially-balanced sampling tool produced by David Theobald, 
# davet@nrel.colostate.edu, and John Norman, Natural Resource Ecology Lab, 
# Colorado State University.
#-----------------------------------------------------------------------------
# Purpose:
# This script creates a spatially-balanced sample within the area specified by an
# extent raster. This tool has the following properties:
# 1. selection probabilities can either be equal or unequal and are specified by the
#    extent (frame) raster.
# 2. Existing sampling locations can be specified and supplemental points will be generated
#    around them.
# 3. Resolution of the input raster (sampling weights or just extent) will determine minimum
#    point spacing of the output
# 4. This implementation does not do stratification.
#-----------------------------------------------------------------------------
# Inputs/Arguments
# gFrame = frame GRID that defines sampling extent and/or sampling weights
# fcExistingPoints = optional point feature class of existing sample locations
# n = number of samples desired
# outfeat = name of output point feature class that will contain locations and IDs of the
#           random sample realization.
#-----------------------------------------------------------------------------


#-----------------------------------------------------------------------------
# Libraries & initializaton
#-----------------------------------------------------------------------------
import sys, os, arcgisscripting, math, random, time
gp = arcgisscripting.create()

print version_info
gp.AddMessage(version_info)

# read arguments
gFrame = gp.GetParameter(0)
fcExistingPoints = gp.GetParameterAsText(1)
seq_ras = gp.GetParameterAsText(2)
inclprob = gp.GetParameterAsText(3)

if __name__ == "__main__":   
    try:
    
        #-----------------------------------------------------------------------------
        # Finish initializing the work environment
        #-----------------------------------------------------------------------------
        
        # Check spatial analyst license and check out extension
        if gp.CheckExtension("spatial") == "Available":
            gp.CheckOutExtension("spatial")
        else:
            raise ReportError(msgNoSAExtension)
        
        # load other required toolboxes
        #check version and get install directory
        installD = gp.GetInstallInfo("desktop")
        for key in installD.keys():
            if key == "InstallDir":
                installpath = installD[key]   
        
        # load other required toolboxes
        gp.AddToolbox(installpath+"ArcToolbox\\Toolboxes\\Data Management Tools.tbx")
        gp.AddToolbox(installpath+"ArcToolbox\\Toolboxes\\Conversion Tools.tbx")
        gp.AddToolbox(installpath+"ArcToolbox\\Toolboxes\\Spatial Analyst Tools.tbx")
        
        #-----------------------------------------------------------------------------
        # validate inputs and initialize environment
        #-----------------------------------------------------------------------------
        
        rasmin = gp.GetRasterProperties(gFrame, "MINIMUM")
        rasmax = gp.GetRasterProperties(gFrame, "MAXIMUM")
        gp.AddMessage("values: "+str(rasmin)+", "+str(rasmax))
        if round(rasmin,2) < 0:
            raise ReportError, (msgWtRasterLT0 + desc.Name)
        if round(rasmax,2) > 1:
            raise ReportError, (msgWtRasterGT1 + desc.Name)
        
        outwork = os.path.split(outfeat)[0]
        outfeat = os.path.split(outfeat)[1]
        if not os.path.exists(outwork):
            raise ReportError, msgOutPathDNE
            
        #Set workspace
        gp.Workspace = outwork
        gp.OverwriteOutput = True
        
        print "Creating inclusion probabilty layer."
        gp.AddMessage("Creating inclusion probabilty layer.")      

        #-----------------------------------------------------------------------------
        # Create the inclusion probability raster
        #-----------------------------------------------------------------------------
        rand_ras = gp.createscratchname("rnd", "", "rasterdataset", gp.Workspace)
        gp.CreateRandomRaster_sa(rand_ras)
        
        #burn existing points into the inclusion probabilities
        if ( fcExistingPoints <> "#"):
            # Get path and Name of Point Featureclass
            samplePTS = gp.Describe(fcExistingPoints).Path + "\\" + gp.Describe(fcExistingPoints).Name
            OutRaster = gp.CreateScratchName("tmp","","rasterdataset",gp.Workspace)
            # Create point Featureclass Raster
            gp.FeatureToRaster_conversion(samplePTS, "ID", OutRaster, str(pCellSize))
            
            # Burn point Raster into inclusion prob grid
            strExp = ("con (isnull(" + OutRaster + ")," + gp.Describe(gFrame).Name + ", 1.0)")
            incProbRas = gp.CreateScratchName("tmp", "", "rasterdataset",gp.Workspace)
            gp.SingleOutputMapAlgebra_sa(strExp, PtBurnIn)
            check_exist(OutRaster)
        else:
            incProbRas = gp.Describe(gFrame).Name
 
        #-----------------------------------------------------------------------------
        # Final stuff
        #-----------------------------------------------------------------------------
        #final cleanup
        check_exist(rand_ras)

        # exit gracefully
        gp.AddMessage(" ")
        gp.AddMessage("       Finished generating inclusion prob raster")
        gp.AddMessage(" ")
        
    #-----------------------------------------------------------------------------
    # Error handling
    #-----------------------------------------------------------------------------
    except ReportError, ErrorMsg: #deals with trapped errors
        gp.AddError("Quitting...")
        print "Quitting..."
    except: # deals with untrapped errors
        gp.AddMessage(gp.GetMessages(2))
        print(gp.GetMessages(2))
