#-----------------------------------------------------------------------------
# Name: spatial_balanced.py
# Author: Jason Karl (see acknowledgment below)
# Version: ArcGIS v9.2+
# Date: Oct 17, 2011
#-----------------------------------------------------------------------------
# Acknowledgment:
# This script is a slightly modified and much simplified implementation of the 
# RRQRR spatially-balanced sampling tool produced by David Theobald, 
# davet@nrel.colostate.edu, and John Norman, Natural Resource Ecology Lab, 
# Colorado State University.
#-----------------------------------------------------------------------------
# Purpose:
# This script creates a spatially-balanced sample within the area specified by an
# extent raster. This tool has the following properties:
# 1. selection probabilities can either be equal or unequal and are specified by the
#    extent (frame) raster.
# 2. Existing sampling locations can be specified and supplemental points will be generated
#    around them.
# 3. Resolution of the input raster (sampling weights or just extent) will determine minimum
#    point spacing of the output
# 4. This implementation does not do stratification.
#-----------------------------------------------------------------------------
# Inputs/Arguments
# gFrame = frame GRID that defines sampling extent and/or sampling weights
# fcExistingPoints = optional point feature class of existing sample locations
# n = number of samples desired
# n_type = OPTION DISABLED - whether n is expressed in absolute terms or as a density in # per ac or # per ha.
#          acceptable values are: "Absolute", "Density per hectare", and "Density per acre."
# outwork = output workspace where files will be written
# outfeat = name of output point feature class that will contain locations and IDs of the
#           random sample realization.
#-----------------------------------------------------------------------------


#-----------------------------------------------------------------------------
# Libraries & initializaton
#-----------------------------------------------------------------------------
import win32com.client, sys, os, arcgisscripting, math, random, time
conn = win32com.client.Dispatch(r'ADODB.Connection')
from sample_functions import *
from sample_error_msgs import *
from version_info import *

gp = arcgisscripting.create()

print version_info
gp.AddMessage(version_info)

# read arguments
gFrame = gp.GetParameter(0)
fcExistingPoints = gp.GetParameterAsText(1)
n = float(gp.GetParameterAsText(2))
outfeat = gp.GetParameterAsText(3)

#gFrame = sys.argv[1]
#fcExistingPoints = sys.argv[2]
#n = float(sys.argv[3])
#outfeat = sys.argv[4]


gp.AddMessage("gFrame="+gp.describe(gFrame).Name)
gp.AddMessage("fcExistingPoints="+fcExistingPoints)
gp.AddMessage("n="+str(n))
gp.AddMessage("outfeat="+outfeat)

if __name__ == "__main__":   
    try:
    
        #-----------------------------------------------------------------------------
        # Finish initializing the work environment
        #-----------------------------------------------------------------------------
        
        # Check spatial analyst license and check out extension
        if gp.CheckExtension("spatial") == "Available":
            gp.CheckOutExtension("spatial")
        else:
            raise ReportError, (msgNoSAExtension)
        
        
        # check if fcExistingPoints argument was given
        if fcExistingPoints == "": fcExistingPoints = "#"
        gp.AddMessage(fcExistingPoints)
        
        # load other required toolboxes
        #check version and get install directory
        installD = gp.GetInstallInfo("desktop")
        for key in installD.keys():
            if key == "InstallDir":
                installpath = installD[key]   
        
        # load other required toolboxes
        gp.AddToolbox(installpath+"ArcToolbox\\Toolboxes\\Data Management Tools.tbx")
        gp.AddToolbox(installpath+"ArcToolbox\\Toolboxes\\Conversion Tools.tbx")
        gp.AddToolbox(installpath+"ArcToolbox\\Toolboxes\\Spatial Analyst Tools.tbx")
        
        #-----------------------------------------------------------------------------
        # validate inputs and initialize environment
        #-----------------------------------------------------------------------------
        
        rasmin = gp.GetRasterProperties(gFrame, "MINIMUM")
        rasmax = gp.GetRasterProperties(gFrame, "MAXIMUM")
        gp.AddMessage("values: "+str(rasmin)+", "+str(rasmax))
        if round(rasmin,2) < 0:
            raise ReportError, (msgWtRasterLT0 + desc.Name)
        if round(rasmax,2) > 1:
            raise ReportError, (msgWtRasterGT1 + desc.Name)
        
        outwork = os.path.split(outfeat)[0]
        outfeat = os.path.split(outfeat)[1]
        if not os.path.exists(outwork):
            raise ReportError, msgOutPathDNE
            
        #Set workspace
        gp.Workspace = outwork
        gp.OverwriteOutput = True
        
        print "Creating spatially balanced sample. This may take some time for large input layers."
        gp.AddMessage("Creating spatially balanced sample. This may take some time for large input layers.")      
     
        
        #-----------------------------------------------------------------------------
        # Create RRQRR sequence raster
        #-----------------------------------------------------------------------------
        
        # compute the number of levels
        pHeight = gp.describe(gFrame).Height
        pWidth = gp.describe(gFrame).Width
        pCells = max(pHeight, pWidth)
        pNumLevels = int(math.floor(math.log(pCells,2)))
        
        # set the extent
        pFrameExtent = gp.Describe(gFrame).Extent
        pExtString = pFrameExtent.split(" ")
        pXMin = float(pExtString[0])
        pYMax = float(pExtString[3])
        pOrigCellSize = gp.Describe(gFrame).MeanCellHeight
        pCellSize = pOrigCellSize        

        strSumExp = "("        
        
        # loop through the levels
        print "Creating sequence raster..."
        gp.AddMessage("Creating sequence raster...")

        pLevel = pNumLevels
        while pLevel >= 1:
            
            print "processing level "+str(pNumLevels-pLevel+1)+" of "+str(pNumLevels)
            gp.AddMessage("processing level "+str(pNumLevels-pLevel+1)+" of "+str(pNumLevels))
            
            # set the environment
            gp.CellSize = pCellSize
            
            # adust the extent so that at each level there are 2 additional columns/rows so that it fills out completely
            x = pCellSize * ( 2 + ( pCells / ( 2**( pNumLevels - pLevel ) ) ) )
            pXMax = pXMin + x
            pYMin = pYMax - x
            pNewExtent = repr(pXMin) + " " + repr(pYMin) + " " + repr(pXMax) + " " + repr(pYMax)
            gp.Extent = pNewExtent

            # Create PERMUTED recursive-4 Numbering
            gR = gp.CreateScratchName("gR","_"+str(pLevel),"rasterdataset",gp.Workspace)
            gp.CreateRandomRaster_sa(gR, "#", pCellSize, pNewExtent )
        
            # Incorporate existing points, if input, into SBS set by adding 1.0 to cells with an existing sample point
            if ( fcExistingPoints <> "#"):
                # Get path and Name of Point Featureclass
                samplePTS = gp.Describe(fcExistingPoints).Path + "\\" + gp.Describe(fcExistingPoints).Name
                OutRaster = gp.CreateScratchName("tmp","","rasterdataset",gp.Workspace)
                # Create point Featureclass Raster
                gp.FeatureToRaster_conversion(samplePTS, "ID", OutRaster, str(pCellSize))
                
                # Burn point Raster into random grid
                strExp = ("con (isnull(" + OutRaster + ")," + gR + "," + gR + " + 1.0)")
                PtBurnIn = gp.CreateScratchName("tmp", "", "rasterdataset",gp.Workspace)
                gp.SingleOutputMapAlgebra_sa(strExp, PtBurnIn)
                check_exist(gR)
                gR = PtBurnIn
                
                # clean up
                check_exist(OutRaster)
                
            gR1 = gp.CreateScratchName("gR1", "", "rasterdataset", gp.Workspace)
            strExp = ("con ( " + gR + " == blockmin( " + gR + ", RECTANGLE, 2, 2), 4.0, " + gR + " )")
            gp.SingleOutputMapAlgebra_sa(strExp, gR1)
            
            gR2 = gp.CreateScratchName("gR2", "", "rasterdataset", gp.Workspace)
            strExp = ("con ( " + gR1 + " == blockmin( " + gR1 + ", RECTANGLE, 2, 2), 3.0, " + gR1 + " )")
            gp.SingleOutputMapAlgebra_sa(strExp, gR2)
            
            gR3 = gp.CreateScratchName("gR3", "", "rasterdataset", gp.Workspace)
            strExp = ("con ( " + gR2 + " == blockmin( " + gR2 + ", RECTANGLE, 2, 2), 2.0, " + gR2 + " )")
            gp.SingleOutputMapAlgebra_sa(strExp, gR3)
            
            gR4 = gp.CreateScratchName("gR4", "", "rasterdataset", gp.Workspace)
            strExp = ("con ( " + gR3 + " < 2.0, 1.0, " + gR3 + " )")
            gp.SingleOutputMapAlgebra_sa(strExp, gR4)
            
            # Change randomly permuted values to 0-3, then compute Morton reversed order
            gRM = gp.CreateScratchName("grmz" + str(pLevel), "", "rasterdataset", gp.Workspace)
            strExp = ("(" + gR4 + " - 1) * POW(4, (" + str(pLevel) + " - 1) ) ")
            gp.SingleOutputMapAlgebra_sa(strExp, gRM)
            
            # Intermediate Clean-up
            check_exist(gR)
            check_exist(gR1)
            check_exist(gR2)
            check_exist(gR3)
            check_exist(gR4)
            
            # get ready for next loop
            strSumExp = strSumExp + gRM + " + "
            pLevel = pLevel - 1
            pCellSize = pCellSize * 2
            
        # sum the orders together
        gp.Mask = gFrame
        gp.CellSize = pOrigCellSize
        strSumExp = strSumExp + "0 )"
        seq_ras = gp.CreateScratchName("sR", "", "rasterdataset", gp.Workspace)
        gp.SingleOutputMapAlgebra_sa(strSumExp, seq_ras)
        
        # intermediate cleanup
        kill_all("grmz","raster", gp.Workspace)
        #-----------------------------------------------------------------------------
        # Create the inclusion probability raster
        #-----------------------------------------------------------------------------
        rand_ras = gp.createscratchname("rnd", "", "rasterdataset", gp.Workspace)
        gp.CreateRandomRaster_sa(rand_ras)
        
        #burn existing points into the inclusion probabilities
        if ( fcExistingPoints <> "#"):
            # Get path and Name of Point Featureclass
            samplePTS = gp.Describe(fcExistingPoints).Path + "\\" + gp.Describe(fcExistingPoints).Name
            OutRaster = gp.CreateScratchName("tmp","","rasterdataset",gp.Workspace)
            # Create point Featureclass Raster
            gp.FeatureToRaster_conversion(samplePTS, "ID", OutRaster, str(pCellSize))
            
            # Burn point Raster into inclusion prob grid
            strExp = ("con (isnull(" + OutRaster + ")," + gp.Describe(gFrame).Name + ", 1.0)")
            incProbRas = gp.CreateScratchName("tmp", "", "rasterdataset",gp.Workspace)
            gp.SingleOutputMapAlgebra_sa(strExp, PtBurnIn)
            check_exist(OutRaster)
        else:
            incProbRas = gp.Describe(gFrame).Path + "\\" + gp.Describe(gFrame).Name
        
        # filter against inclusion probabilities
        strExp = "int(con( " + incProbRas + " > "+rand_ras+", " + seq_ras + " ))"
        FltSeq_ras = gp.CreateScratchName("FsR", "", "rasterdataset", gp.Workspace)
        gp.SingleOutputMapAlgebra_sa(strExp, FltSeq_ras)
        
        # intermediate cleanup
        check_exist(rand_ras)
        check_exist(seq_ras)
        
        #-----------------------------------------------------------------------------
        # Create the point selection
        #-----------------------------------------------------------------------------        
        smpts = gp.CreateScratchName("smpts", "", "shapefile", gp.Workspace)
        gp.RasterToPoint_conversion(FltSeq_ras, smpts) # export rater to featureclass to be sorted
        gp.CreateFeatureclass(gp.Workspace, outfeat, "POINT") #Create blank feature class to be populated with sample point ini order
        gp.addfield(outfeat, "order_", "long", "6")
        gp.addfield(outfeat, "inc_prob", "Double", "9", "9")        
        
        # Set up BSN connection to DBF tables in gp.Workspace
        gp.AddMessage("Generating ordered list")        
        
        DSN = "Driver={Microsoft dBASE Driver (*.dbf)}; DriverID=277; Dbq=" + gp.Workspace
        conn.Open(DSN)
        rs1 = win32com.client.Dispatch(r'ADODB.Recordset')
        dbfname = gp.Describe(smpts).Name[0:-4]
        querystring = "SELECT * FROM "+dbfname+" ORDER BY "+dbfname+".GRID_CODE"
        rs1.Open(querystring, conn, 1)
        rs1.MoveFirst()
        count = 0
        OrderList = [] # this list hold the order of sample points
        while not rs1.EOF:
            #gp.AddMessage(str(count))
            if count < long(n):
                OrderList.append(rs1.Fields.Item("GRID_CODE").Value)
                pntvalue = rs1.Fields.Item("GRID_CODE").Value
            else:
                break
            count = count + 1
            rs1.MoveNext()
        rs1 = "Nothing"
        conn = "Nothing"
        
        # select the corresponding records from the smpts feature class and write them to outfeat
        querystring = "\"GRID_CODE\" <= " + str(pntvalue) + " ORDER BY \"GRID_CODE\""        
        
        
        gp.AddMessage("4")
        gp.MakeFeatureLayer(smpts, "templayer", querystring)
        tmppts = gp.CreateScratchName("t","","shapefile",gp.Workspace)
        gp.CopyFeatures("templayer",tmppts)
        CorrCur = gp.InsertCursor(outfeat) # set up insertcursor to order points
        for element in OrderList:
            rows = gp.SearchCursor(tmppts) # this search cursor is to loop through all points and get attributes
            row = rows.Next()
            while row:
                if row.getvalue("GRID_CODE") == element:
                    newfeat = CorrCur.newrow()
                    featshape = row.shape
                    newfeat.setvalue("shape", featshape.GetPart())
                    newfeat.setvalue("Id", row.getvalue("POINTID"))
                    newfeat.setvalue("order_", element)
                    CorrCur.insertrow(newfeat)
                    break
                row = rows.Next()
        rows = "nothing"
        row = "nothing"
        
        #Get Inclusion probability values for each point from input raster
        gp.AddMessage("5")
        inc_prob = gp.CreateScratchName("incprob",".dbf","dataset",gp.Workspace)
        gp.ZonalStatisticsAsTable_sa(outfeat, "ID", gFrame, inc_prob, "DATA")
        gp.MakeFeatureLayer(outfeat, "joinlayer")
        gp.AddJoin_management("joinlayer", "Id", gp.describe(inc_prob).name, "ID")
        gp.calculatefield("joinlayer", "inc_prob", "["+gp.describe(inc_prob).name[0:-4]+".MEAN]") # calc thickness to inclusion probability to keep from adding new field. B/c dealing with point data mean is the cell value
        gp.RemoveJoin("joinlayer", gp.describe(inc_prob).name[0:-4])

        
        #-----------------------------------------------------------------------------
        # Final stuff
        #-----------------------------------------------------------------------------
        #final cleanup
        check_exist(smpts)
        check_exist(inc_prob)
        check_exist(FltSeq_ras)
        check_exist(tmppts)

        # exit gracefully
        gp.AddMessage(" ")
        gp.AddMessage("       Finished generating sample points")
        gp.AddMessage(" ")
        
    #-----------------------------------------------------------------------------
    # Error handling
    #-----------------------------------------------------------------------------
    except ReportError, ErrorMsg: #deals with trapped errors
        gp.AddError("Quitting...")
        print "Quitting..."
    except: # deals with untrapped errors
        gp.AddMessage(gp.GetMessages(2))
        print(gp.GetMessages(2))
