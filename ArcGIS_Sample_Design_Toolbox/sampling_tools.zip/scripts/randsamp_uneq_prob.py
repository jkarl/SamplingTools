#-----------------------------------------------------------------------------
# Name:
# Author: Jason Karl
# Version: ArcGIS v9.2+
# Date: April 2, 2010
#-----------------------------------------------------------------------------
# Purpose:
# This script draws random samples from within the input layers according to
# the following properties:
# 1. selection probabilities are unequal and are defined by a raster input layer 
#    (raster layer does not need to be expressed as probabilities)
# 2. Random locations are generates within an extent defined by an input polygon layer.
# 3. the number of points desired can be expressed in absolute terms or as a density of points
#    The script checks to see if densities are valid for the study area.
#-----------------------------------------------------------------------------
# Inputs/Arguments
# extent_layer = feature class specifying extent of sample locations
# msd = minimum distance separating random locations
# dist_type = whether minimum distance is maximum plot dimension or some other desired minimum distance
# sel_prob_surf = surface (raster) defining the selection probabilities for generating random locations.
#            If not specified, then assume equal selection probabilities.
# n = number of samples desired
# n_type = whether n is expressed in absolute terms or as a density in # per ac or # per ha.
#          acceptable values are: "Absolute", "Density per hectare", and "Density per acre."
# outfeat = name of output point feature class that will contain locations and IDs of the
#           random sample realization.
#-----------------------------------------------------------------------------

#-----------------------------------------------------------------------------
# Libraries & initializaton
#-----------------------------------------------------------------------------
import win32com.client, sys, os, arcgisscripting, math, random
from sample_functions import *
from sample_error_msgs import *
from version_info import *

gp = arcgisscripting.create()

print version_info
gp.AddMessage(version_info)

# read arguments
extent_layer = sys.argv[1]
distunits = sys.argv[2]
sel_prob_surf = sys.argv[3]
n = sys.argv[4]
n_type = sys.argv[5]
outfeat = sys.argv[6]   
    
try: 

    #-----------------------------------------------------------------------------
    # Finish initializing the work environment
    #-----------------------------------------------------------------------------
    
    # check out spatial analyst extension
    if gp.CheckExtension("spatial") == "Available":
        gp.CheckOutExtension("spatial")
    else:
        raise ReportError, msgLicenseError

    # load other required toolboxes
        #check version and get install directory
    installD = gp.GetInstallInfo("desktop")
    for key in installD.keys():
        if key == "InstallDir":
            installpath = installD[key]   
    
    # load other required toolboxes
    gp.AddToolbox(installpath+"ArcToolbox\\Toolboxes\\Data Management Tools.tbx")
    gp.AddToolbox(installpath+"ArcToolbox\\Toolboxes\\Conversion Tools.tbx")  
    gp.AddToolbox(installpath+"ArcToolbox\\Toolboxes\\Spatial Analyst Tools.tbx")  
    
    #-----------------------------------------------------------------------------
    # validate arguments and initialize
    #-----------------------------------------------------------------------------
    gp.AddMessage("Checking arguments")
    print("Checking arguments")

    if extent_layer == "#":
        extent_layer = "C:\\Users\\Jason\\Dropbox\\sampling_tools\\d0.shp"
    if not gp.exists(extent_layer):
        raise ReportError, (msgInputDNE + samp_frame)
    # check to see if it is a polygon layer
    desc = gp.Describe(extent_layer)
    extent = desc.extent
    st = desc.ShapeType
    if not st.lower() == "polygon": raise ReportError, msgExtentNotPoly
    SR = desc.SpatialReference
    if not SR.Type == "Projected": raise ReportError, msgExtentNotProjected
    
    if sel_prob_surf == "#":
        sel_prob_surf = "C:\\Users\\Jason\\Dropbox\\sampling_tools\\dst_test"
    if not sel_prob_surf == "#":
        if not gp.exists(sel_prob_surf):
            raise ReportError, (msgInputDNE + sel_prob_surf)
    
    # parse out the distance from the units and convert to meters
    if distunits == "#":
        distunits = "100 Meters"
    h = distunits.split()
    dist = float(h[0])
    units = h[1]
    msd = convert2meters(dist,units)
    
    if n == "#":
        n = 200
    
    if n_type == "#":
        n_type = "total number of points"
    if not n_type.lower() in ["points per acre", "points per hectare", "total number of points", "1 point per x acres", "1 point per x hectares"]:
        raise ReportError, msgInvalidNtype
        
    if outfeat == "#":
        outfeat = "C:\\Users\\Jason\\Dropbox\\sampling_tools\\test_uneq7.shp"
    outwork = os.path.split(outfeat)[0]
    outfeat = os.path.split(outfeat)[1]
    if not os.path.exists(outwork):
        raise ReportError, msgOutPathDNE
        
    #Set workspace
    gp.Workspace = outwork
    gp.OverwriteOutput = True

    # Check output layer and delete if exists
    if not check_exist(outfeat): raise ReportError, msgOutputExists

    print("Creating Sample")
    gp.AddMessage("Creating Sample")
    
    #---------------------------------------------------------------------------
    # generate random locations within a study extent
    #---------------------------------------------------------------------------            
    print "Creating random sample. This may take some time for large input layers."
    gp.AddMessage("Creating random sample. This may take some time for large input layers.")    
    
    # because input extent is a feature set, need to convert it to a featureclass
    extLayerCopy = gp.CreateScratchName("e","","shapefile",gp.Workspace)
    gp.CopyFeatures(extent_layer, extLayerCopy)
    
    # get the extent layer, set it as the analysis mask
    orig_mask = gp.mask # save the original mask to restore later
    gp.mask = extLayerCopy        
    
    # create random raster surface with cell size set by msd
    rand_ras = gp.CreateScratchName("g","","raster",gp.Workspace)
    if not check_exist(rand_ras): raise ReportError, msgTempExists
    gp.CreateRandomRaster_sa(rand_ras, "", msd, extent)     
    gp.mask = orig_mask  # remove mask
    
    # convert raster to point layer (don't really need the random numbers, but this forces a point for each grid cell)
    grid_pts = gp.CreateScratchName("gp","","shapefile",gp.Workspace)
    if not check_exist(grid_pts): raise ReportError, msgTempExists
    gp.RasterToPoint_conversion(rand_ras, grid_pts, "Value")
    
    # find sel probs for each point from sel_prob_surf, or calc equal sample probs
    if sel_prob_surf == "#":  # Equal selection probabilities
        samp_units = grid_pts
        prob_attr = "#"   # originally defined for selecting from feature classes, but use as a flag to signal equal/unequal prob selection here
    else:
        sel_probs = gp.CreateScratchName("d","","shapefile",gp.Workspace)[:-3] + "dbf"
        if not check_exist(sel_probs): raise ReportError, msgTempExists
        gp.Sample_sa(sel_prob_surf, grid_pts, sel_probs, "NEAREST")
        samp_units = sel_probs
        prob_attr = "unequal"  # just needs to be something other than default hash.
        #---------------------------------------------------------------          
        

    # Get the name of the last field which will have the sample probs.
    desc = gp.Describe(samp_units)
    fields = desc.Fields
    field = fields.Next()
    while field:
        name = field.Name
        field = fields.Next()
    desc = "nothing"
    if field: del field
    if fields: del fields
    
    temp = getIDandProbLists(samp_units, name)
    if temp[0] == -1: raise ReportError, "error enumerating random sampling locations."
    IDlist = temp[0]
    Pi = temp[1]

    #-----------------------------------------------------------------------
        
    # Calculate selection probabilities if none exist
    Pi = calcSelProbs(IDlist, Pi, prob_attr)

    # now pair up the IDs and selection probabilities
    c = zip(IDlist, Pi)
    
    # randomize the order of the lists
    random.shuffle(c)

    #---------------------------------------------------------------------------
    # Calculate number of samples if a density option was selected
    #---------------------------------------------------------------------------
    n = calc_num_samps(extent_layer, "shapefile", n_type, n, msd)
    gp.AddMessage(str(n))
    if n < 0: raise ReportError, msgSampSizeError
    if n > len(IDlist): raise ReportError, msgSampSizeError
    
    #---------------------------------------------------------------------------
    # Select samples from array
    #---------------------------------------------------------------------------
    temp = selectSamples(prob_attr, c, n)
    if temp[0] == -1: raise ReportError, "error encountered in selecting random samples."
    z = zip(temp[0],temp[1])  # do some sorting so the points go in according to the feature ID order
    z.sort()
    Selected, selPi = zip(*z)
    #Selected = temp[0]
    #selPi = temp[1]
    
    gp.AddMessage(Selected)
    print(len(Selected))
    
    print("almost done")

    #-----------------------------------------------------------------------------
    # Select the random samples from the input shapefile and write them to the output shapefile
    #-----------------------------------------------------------------------------
    print "writing output dataset"
    gp.AddMessage("Writing output dataset.")
    
    #Pull selected units from the file and write to new point shapefile
    samp_units = grid_pts
    
    if createSelOutput(Selected, selPi, samp_units, gp.Workspace+"\\"+outfeat):
        print "Finished!"
        gp.AddMessage("Finished")
    else: 
        print "error encountered"
        print gp.GetMessages()
    
    # delete temporary datasets
    if not check_exist(sel_probs): raise ReportError, "error deleting temporary dataset " + sel_probs
    if not check_exist(rand_ras): raise ReportError, "error deleting temporary dataset " + rand_ras
    if not check_exist(grid_pts): raise ReportError, "error deleting temporary dataset " + grid_pts
    if not check_exist(extent): raise ReportError, "error deleting temporary dataset " + extent
    
    
#-----------------------------------------------------------------------------
# Error handling
#-----------------------------------------------------------------------------
except ReportError, ErrorMsg: #deals with trapped errors
    gp.AddError(ErrorMsg)
    print ErrorMsg
    gp.AddError("Quitting...")
    print "Quitting..."
except: # deals with untrapped errors
    gp.AddMessage("Error encountered")
    gp.AddMessage(gp.GetMessages(2))
    print(gp.GetMessages(2))
