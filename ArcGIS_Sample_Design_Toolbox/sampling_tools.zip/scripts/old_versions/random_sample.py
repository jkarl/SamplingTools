#-----------------------------------------------------------------------------
# Name:
# Author: Jason Karl
# Version: ArcGIS v9.2+
# Date: April 2, 2010
#-----------------------------------------------------------------------------
# Purpose:
# This script draws random samples from within the input layers according to
# the following properties:
# 1. selection probabilities can either be equal or unequal
# 2. with equal selection probabilities, this algorithm is akin to simple random
#    selection.
# 3. Random selections can be made of features from an input feature class, or
# 4. Random locations can be selected within an extent.
#-----------------------------------------------------------------------------
# Inputs/Arguments
# sel_from_layer = boolean. make random selection from a feature class layer
# samp_units = Conditional on sel_from_layer. A vector layer of the sample frame
#            where each feature is a sampling unit. 
# prob_attr = Conditional on sel_from_layer. Optional. attribute in the samp_units layer that identifies
#             the attribute that contains the inclusions probabilities. If #, assume equal
#	      selection probs.
# gen_rand_locs = Boolean. Generate random locations within an extent
# extent_layer = feature class specifying extent of sample locations
# msd = minimum distance separating random locations
# dist_type = whether minimum distance is maximum plot dimension or some other desired minimum distance
# sel_prob_surf = surface (raster) defining the selection probabilities for generating random locations.
#            If not specified, then assume equal selection probabilities.
# n = number of samples desired
# n_type = whether n is expressed in absolute terms or as a density in # per ac or # per ha.
#          acceptable values are: "Absolute", "Density per hectare", and "Density per acre."
# exist_samp = existing sampling locations that will be mandated in the output
# outwork = output workspace where files will be written
# outfeat = name of output point feature class that will contain locations and IDs of the
#           random sample realization.
#-----------------------------------------------------------------------------

#-----------------------------------------------------------------------------
# Libraries & initializaton
#-----------------------------------------------------------------------------
import win32com.client, sys, os, arcgisscripting, math, random
from sample_functions import *

gp = arcgisscripting.create()

# Setup error messages
ReportError = "CustomErrorHandler"
msgLicenseError = "Spatial Analyst extension not available"
msgInputDNE = "The following input layer does not exist or cannot be found: "
msgAttributeDNE = "Could not find the attribute defining the sampling probabilities in the sampling units layer."
msgOutPathDNE = "Output directory does not exist."
msgOutputExists = "Output feature layer already exists and cannot be deleted."
msgTempExists = "A necessary temporary file exists and cannot be deleted."
msgExtentNotPoly = "Extent layer must be a polygon layer."
msgExtentNotProjected = "Extent layer must be in a projected coordinate system and have the coordinate system defined to use the point density option."
msgSampSizeError = "An error was encountered in calculating the sample size from the density requirement."

# read arguments
sel_from_layer = sys.argv[1]
samp_units = sys.argv[2]
prob_attr = sys.argv[3]
gen_rand_locs = sys.argv[4]
extent_layer = sys.argv[5]
msd = sys.argv[6]
dist_type = sys.argv[7] # not really necessary, but that's OK
sel_prob_surf = sys.argv[8]
n = sys.argv[9]
n_type = sys.argv[10]
exist_samp = sys.argv[11]
outwork = sys.argv[12]
outfeat = sys.argv[13]   
    
try: 

    #-----------------------------------------------------------------------------
    # Finish initializing the work environment
    #-----------------------------------------------------------------------------
    
    # check out spatial analyst extension
    if gp.CheckExtension("spatial") == "Available":
        gp.CheckOutExtension("spatial")
    else:
        raise ReportError, msgLicenseError

    # load other required toolboxes
    gp.AddToolbox("C:/Program Files (x86)/ArcGIS/ArcToolbox/Toolboxes/Data Management Tools.tbx")
    gp.AddToolbox("C:/Program Files (x86)/ArcGIS/ArcToolbox/Toolboxes/Spatial Analyst Tools.tbx")
    gp.AddToolbox("C:/Program Files (x86)/ArcGIS/ArcToolbox/Toolboxes/Conversion Tools.tbx")
    
    #-----------------------------------------------------------------------------
    # validate arguments and initialize
    #-----------------------------------------------------------------------------
    gp.AddMessage("Checking arguments")
    print("Checking arguments")

    if samp_units == "#":
        samp_units = "C:\\Users\\jasonkarl\\Documents\\Multi_Scale_Assessment\\analysis\\castle_creek_scale\\Scale50.shp"
    if not gp.exists(samp_units):
        raise ReportError, (msgInputDNE + samp_units)    

    if prob_attr == "#":
        prob_attr = "Mean_Lay_1"
    # check to see if attribute exists
    ds = gp.Describe(samp_units)
    fields = ds.Fields
    field = fields.next()
    flag = False
    while field:
        if field.Name == prob_attr:
            flag = True
            break
        field = fields.next()
    if not flag:
        raise ReportError, msgAttributeDNE    
    
    if extent_layer == "#":
        extent_layer = "C:\\Users\\jasonkarl\\Documents\\Multi_Scale_Assessment\\geodata\\Castle_Creek\\castle_Creek_study_boundary.shp"
    if not gp.exists(extent_layer):
        raise ReportError, (msgInputDNE + samp_frame)
    # check to see if it is a polygon layer
    desc = gp.Describe(extent_layer)
    st = desc.ShapeType
    if not st.lower() == "polygon": raise ReportError, msgExtentNotPoly
    
    if sel_prob_surf == "#":
        sel_prob_surf = "C:\\Users\\jasonkarl\\Documents\\My Dropbox\\sampling_tools\\dst_test"
    if not sel_prob_surf == "#":
        if not gp.exists(sel_prob_surf):
            raise ReportError, (msgInputDNE + sel_prob_surf)
    
    if n == "#":
        n = 0.003
    else:
        n = float(n)

    if n_type == "#":
        n_type = "Density per acre"
    if not n_type == "Absolute": # if using one of the density options, need to make sure the extent layer is projected.
        SR = desc.SpatialReference
        if not SR.Type == "Projected": raise ReportError, msgExtentNotProjected
        
    if not exist_samp == "#":
        if not gp.exists(exist_samp):
            raise ReportError, (msgInputDNE + exist_samp)        
        
    if outwork == "#":
        outwork = "C:\\Users\\jasonkarl\\Documents\\My Dropbox\\sampling_tools"
    if not os.path.exists(outwork):
        raise ReportError, msgOutPathDNE
        
    #Set workspace
    gp.Workspace = outwork
    gp.OverwriteOutput = True

    # Check output layer and delete if exists
    if outfeat == "#":
        outfeat = "test_sample.shp"
    if not check_exist(outfeat): raise ReportError, msgOutputExists

    #-----------------------------------------------------------------------------
    # Polygon inc_prob layer - enumerate features and inc probs
    #-----------------------------------------------------------------------------
    if int(sel_from_layer):
        
        temp = getIDandProbLists(samp_units, prob_attr)
        if temp[0] == -1: raise ReportError, "error enumerating features and inclusion probabilities"
        IDlist = temp[0]
        Pi = temp[1]
        #-----------------------------------------------------------------------
        
    #---------------------------------------------------------------------------
    # generate random locations within a study extent
    #---------------------------------------------------------------------------            
    if int(gen_rand_locs):
        # get the extent layer, set it as the analysis mask
        orig_mask = gp.mask # save the original mask to restore later
        gp.mask = extent_layer        
        
        # create random raster surface with cell size set by msd
        if not check_exist("rand_ras"): raise ReportError, msgTempExists
        gp.CreateRandomRaster_sa("rand_ras", "", msd, extent_layer)     
        gp.mask = orig_mask  # remove mask
        
        # convert raster to point layer (don't really need the random numbers, but this forces a point for each grid cell)
        if not check_exist("grid_pts"): raise ReportError, msgTempExists
        gp.RasterToPoint_conversion("rand_ras", "grid_pts", "Value")
        
        # find sel probs for each point from sel_prob_surf, or calc equal sample probs
        if sel_prob_surf == "#":  # Equal selection probabilities
            samp_units = "grid_pts.shp"
            prob_attr = "#"   # originally defined for selecting from feature classes, but use as a flag to signal equal/unequal prob selection here
        else:
            if not check_exist("sel_probs.dbf"): raise ReportError, msgTempExists
            gp.Sample_sa(sel_prob_surf, "grid_pts.shp", "sel_probs.dbf", "NEAREST")
            samp_units = "sel_probs.dbf"
            prob_attr = "unequal"  # just needs to be something other than default hash.
            #---------------------------------------------------------------          
            
   
        # Get the name of the last field which will have the sample probs.
        desc = gp.Describe(samp_units)
        fields = desc.Fields
        field = fields.Next()
        while field:
            name = field.Name
            field = fields.Next()
        desc = "nothing"
        if field: del field
        if fields: del fields
        
        temp = getIDandProbLists(samp_units, name)
        if temp[0] == -1: raise ReportError, "error enumerating random sampling locations."
        IDlist = temp[0]
        Pi = temp[1]

    #-----------------------------------------------------------------------
        
    # Calculate selection probabilities if none exist
    Pi = calcSelProbs(IDlist, Pi, prob_attr)

    # now pair up the IDs and selection probabilities
    c = zip(IDlist, Pi)
        
    # randomize the order of the lists
    random.shuffle(c)

    #---------------------------------------------------------------------------
    # Calculate number of samples if a density option was selected
    #---------------------------------------------------------------------------
    n = calc_num_samps(extent_layer, n_type, n)
    if n < 0: raise ReportError, msgSampSizeError
    if n > len(IDlist): raise ReportError, msgSampSizeError
    
    #---------------------------------------------------------------------------
    # Select samples from array
    #---------------------------------------------------------------------------
    temp = selectSamples(prob_attr, c, n)
    if temp[0] == -1: raise ReportError, "error encountered in selecting random samples."
    Selected = temp[0]
    selPi = temp[1]
    
    print(Selected)
    print(len(Selected))
    
    print("almost done")

    #-----------------------------------------------------------------------------
    # Select the random samples from the input shapefile and write them to the output shapefile
    #-----------------------------------------------------------------------------
    #Pull selected units from the file and write to new point shapefile
    if gen_rand_locs:
        if not prob_attr == "#":
            samp_units = "grid_pts.shp"
    
    if createSelOutput(Selected, selPi, samp_units, outfeat):
        print "Finished!"
        gp.AddMessage("Finished")
    else: 
        print "error encountered"
        print gp.GetMessages()
    
    # delete temporary datasets
    if gp.Exists("rand_ras"): gp.Delete("rand_ras")
    if gp.Exists("grid_pts.shp"): gp.Delete("grid_pts.shp")
    if gp.Exists("sel_probs.dbf"): gp.Delete("sel_probs.dbf")
    
    
#-----------------------------------------------------------------------------
# Error handling
#-----------------------------------------------------------------------------
except ReportError, ErrorMsg: #deals with trapped errors
    gp.AddError(ErrorMsg)
    print ErrorMsg
    gp.AddError("Quitting...")
    print "Quitting..."
except: # deals with untrapped errors
    gp.AddMessage(gp.GetMessages(2))
    print(gp.GetMessages(2))
