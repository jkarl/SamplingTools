#-----------------------------------------------------------------------------
# Name: strat_randsel_uneq_prob.py
# Author: Jason Karl
# Version: ArcGIS v9.2+
# Date: April 2, 2010
#-----------------------------------------------------------------------------
# Purpose:
# This script draws stratified random samples from within an input layer according to
# the following properties:
# 1. selection probabilities are equal 
# 2. Random selections are made of features from an input feature class
# 3. A field of the input attribute table specifies the strata
# 4. The number of points to be selected can be expressed in absolute terms or as a density
# 5. The number of features selected per stratum can be the same across stratum or vary by
#    stratum. If variable, then a field is used to identify the number of samples to be selected
#    for each stratum. Because there will be many features for each unique stratum value in the
#    attribute table, each feature in the stratum should have the same number in the sample size
#    field.
#-----------------------------------------------------------------------------
# Inputs/Arguments
# samp_units = A feature set defining the sample frame where each feature is a sampling unit. 
# stratum_field = attribute of the sample_units feature set that identifies the strata
# fixed_or_variable = will a fixed number of samples be drawn from each stratum, or will it vary by stratum?
# n = number of samples desired. Conitional on fixed
# n_field = field of the input polygon feature class that defines how many samples will be drawn per stratum.
#           Conditional on variable.
# n_type = whether n is expressed in absolute terms or as a density in # per ac or # per ha.
#          acceptable values are: "Absolute", "Density per hectare", and "Density per acre."
# outfeat = name of output point feature class that will contain the randomly-selected features
#-----------------------------------------------------------------------------

#-----------------------------------------------------------------------------
# Libraries & initializaton
#-----------------------------------------------------------------------------
import win32com.client, sys, os, arcgisscripting, math, random
from sample_functions import *

gp = arcgisscripting.create()

# Setup error messages
ReportError = "CustomErrorHandler"
msgLicenseError = "Spatial Analyst extension not available"
msgInputDNE = "The following input layer does not exist or cannot be found: "
msgAttributeDNE = "Could not find the attribute defining the sampling probabilities in the sampling units layer."
msgOutPathDNE = "Output directory does not exist."
msgOutputExists = "Output feature layer already exists and cannot be deleted."
msgTempExists = "A necessary temporary file exists and cannot be deleted."
msgExtentNotPoly = "Extent layer must be a polygon layer."
msgExtentNotProjected = "Extent layer must be in a projected coordinate system and have the coordinate system defined to use the point density option."
msgSampSizeError = "An error was encountered in calculating the sample size from the density requirement."
msgAttributeTypeWrong = "The attribute specified for the selection probabilities is not a numeric field."
    
# read arguments
samp_units_fs = gp.GetParameters(0)
stratum_field = sys.argv[2]
fixed_or_variable = sys.argv[3]
n = float(sys.argv[4])
n_field = sys.argv[5]
n_type = sys.argv[6]
outfeat = sys.argv[7]   
    
try:

    #-----------------------------------------------------------------------------
    # Finish initializing the work environment
    #-----------------------------------------------------------------------------
    
    # load other required toolboxes
    gp.AddToolbox("C:/Program Files (x86)/ArcGIS/ArcToolbox/Toolboxes/Data Management Tools.tbx")
    gp.AddToolbox("C:/Program Files (x86)/ArcGIS/ArcToolbox/Toolboxes/Conversion Tools.tbx")
    
    #-----------------------------------------------------------------------------
    # validate arguments and initialize
    #-----------------------------------------------------------------------------
    gp.AddMessage("Checking arguments")
    print("Checking arguments")

    if samp_units_fs == "#":
        samp_units_fs = "C:\\Users\\jasonkarl\\Documents\\Multi_Scale_Assessment\\analysis\\castle_creek_scale\\Scale50.shp"
    if not gp.exists(samp_units_fs):
        raise ReportError, (msgInputDNE + samp_units_fs)    
    # check to see if it is a polygon layer
    desc = gp.Describe(samp_units_fs)
    st = desc.ShapeType
    if not st.lower() == "polygon": raise ReportError, msgExtentNotPoly
    SR = desc.SpatialReference

    # check to see if the stratum_field exists
    if stratum_field == "#":
        stratum_field = "ID"
    # check to see if attribute exists and that it's numeric
    if not CheckField(stratum_fs, stratum_field, "categorical"): raise ReportError, msgAttributeDNE       
    
   # check the sample size arguments
    if fixed_or_variable.lower() == "#": fixed_or_variable = "variable"
    if fixed_or_variable.lower() == "fixed":
        if n == "#": n = float(500)
        else: float(n)
    else:
        if n_field == "#": n_field = "numpoints"
        if not CheckField(stratum_fs, n_field, "numeric"): raise ReportError, msgAttributeDNE
    
    # check the sample size type argument
    if n_type == "#":
        n_type = "total number of points"
    if not n_type.lower() in ["points per acre", "points per hectare", "total number of points", "1 point per x acres", "1 point per x hectares"]:
        raise ReportError, msgInvalidNtype
    
    # get the output feature class name and directory
    if outfeat == "#":
        outfeat = "C:\\Users\\jasonkarl\\Documents\\My Dropbox\\sampling_tools\\test_stratrs11.shp"
    outwork = os.path.split(outfeat)[0]
    outfeat = os.path.split(outfeat)[1]
    if not os.path.exists(outwork):
        raise ReportError, msgOutPathDNE
        
    #Set workspace
    gp.Workspace = outwork
    gp.OverwriteOutput = True

    # Check output layer and delete if exists
    if not check_exist(outfeat): raise ReportError, msgOutputExists

    #---------------------------------------------------------------------------
    #Start iteration over the strata
    #---------------------------------------------------------------------------
    
    # get the list of unique strata
    strataList = getUniqueValues(samp_units_fs, stratum_field)
    
    # set up a temporary feature class to hold the selections
    hold = gp.CreateFeatureclass("in_memory", "hold", desc.shapetype, samp_units_fs, "#", "#", SR)
    gp.addfield(hold, "CID", "LONG", "9")
    gp.addfield(hold, "Stratum", "TEXT")
    
    # start iteration over the strata
    for i in strataList:
    
    # Select out features belonging to a stratum to a temporary feature class
        gp.MakeFeatureLayer_management(samp_units_fs, "lyr")
        gp.SelectLayerByAttribute_management("lyr", "NEW_SELECTION", '"' + stratum_field + '" = ' + i)
        stratum_units = gp.CopyFeatures("lyr", "in_memory\\stratum_units")

        #-----------------------------------------------------------------------------
        # Polygon inc_prob layer - enumerate features and inc probs
        #-----------------------------------------------------------------------------
        temp = getIDandProbLists(stratum_units, "#")
        if temp[0] == -1: raise ReportError, "error enumerating features and inclusion probabilities"
        IDlist = temp[0]
        Pi = temp[1]
        
        # Calculate selection probabilities
        Pi = calcSelProbs(IDlist, Pi, "#")

        # now pair up the IDs and selection probabilities
        c = zip(IDlist, Pi)
        
        # randomize the order of the lists
        random.shuffle(c)

        #---------------------------------------------------------------------------
        # Calculate number of samples if a density option was selected
        #---------------------------------------------------------------------------
        if fixed_or_variable == "variable": # need to set n from the featureset if variable option selected
            rs = gp.SearchCursor(stratum_units)
            r = rs.Next()
            n = r.GetValue(n_field)
            del r
            del rs
        n = calc_num_samps(stratum_units, n_type, n, 1) #function requires a minimum sep distance, supply 1
        gp.AddMessage(str(n))
        if n < 0: raise ReportError, msgSampSizeError
        if n > len(IDlist): raise ReportError, msgSampSizeError
        
        #---------------------------------------------------------------------------
        # Select samples from array
        #---------------------------------------------------------------------------
        temp = selectSamples(prob_attr, c, n)
        if temp[0] == -1: raise ReportError, "error encountered in selecting random samples."
        Selected = temp[0]
        selPi = temp[1]
    
        print(Selected)
        print(len(Selected))
    
        #--------------------------------------------------------------------------
        # pull random samples from the temporary feature class and append to hold
        #--------------------------------------------------------------------------
        # create part of the SQL string from Selected
	l = ""
        for x in Selected:
            l = l + str(x) + ","
        l = l[:-1]
	
        lyr = gp.MakeFeatureLayer_management(stratum_units, "lyr")
        gp.SelectLayerByAttribute_management(lyr, "NEW_SELECTION", "\"FID\" IN (" + l + ")")
        gp.CopyFeatures(lyr, hold)
        gp.Append_management(stratum_units, hold)
        gp.Delete_management(stratum_units)
        
    print("almost done")

    #-----------------------------------------------------------------------------
    # Select the random samples from the input shapefile and write them to the output shapefile
    #-----------------------------------------------------------------------------
    #Pull selected units from the file and write to new point shapefile
    if createSelOutput(Selected, selPi, samp_units, gp.Workspace+"\\"+outfeat):
        print "Finished!"
        gp.AddMessage("Finished")
    else: 
        print "error encountered"
        print gp.GetMessages()
    
    # delete temporary datasets
    if not check_exist(samp_units): raise ReportError, "error deleting temporary dataset " + samp_units
    
    
#-----------------------------------------------------------------------------
# Error handling
#-----------------------------------------------------------------------------
except ReportError, ErrorMsg: #deals with trapped errors
    gp.AddError(ErrorMsg)
    print ErrorMsg
    gp.AddError("Quitting...")
    print "Quitting..."
except: # deals with untrapped errors
    gp.AddMessage(gp.GetMessages(2))
    print(gp.GetMessages(2))
