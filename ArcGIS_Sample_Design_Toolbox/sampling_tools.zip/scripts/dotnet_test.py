import win32com.client, sys, os, arcgisscripting, math, random

gp = arcgisscripting.create()

test = sys.argv[1]
