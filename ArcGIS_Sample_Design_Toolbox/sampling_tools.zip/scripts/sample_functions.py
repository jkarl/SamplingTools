# reusable functions for the sample design tools

import sys, os, arcgisscripting, math, random, time

gp = arcgisscripting.create(9.3)

#check version and get install directory
installD = gp.GetInstallInfo("desktop")
for key in installD.keys():
    if key == "InstallDir":
	installpath = installD[key]


# load required toolboxes
gp.AddToolbox(installpath+"ArcToolbox\\Toolboxes\\Data Management Tools.tbx")
gp.AddToolbox(installpath+"ArcToolbox\\Toolboxes\\Spatial Analyst Tools.tbx")
gp.AddToolbox(installpath+"ArcToolbox\\Toolboxes\\Conversion Tools.tbx") 

#-------------------------------------------------------------------------------
# Common functions used in sample design tools
#-------------------------------------------------------------------------------

# ------------------------------------------------------------------------------
# Check for existence of a layer and delete if it exists
# ------------------------------------------------------------------------------
def check_exist(layer):
    try:
        if gp.Exists(layer):
            gp.Delete(layer)
        return 1
    except:
        return 0

# ------------------------------------------------------------------------------
# Deletes all datasets of one type in a directory that match a wildcard prefix combination (e.g., "grd*")
# ------------------------------------------------------------------------------
def kill_all(name, type, ws):
    try:
	gp.Workspace = ws
	if type == "featureclass":
	    list = gp.ListFeatureClasses(name+"*")
	if type == "raster":
	    list = gp.ListRasters(name+"*", "ALL")
	for dataset in list:
	    check_exist(dataset)
	return 1
    except:
	return 0
    
    
# ------------------------------------------------------------------------------
# Calculate number of samples if density option selected
# ------------------------------------------------------------------------------
def calc_num_samps(input, type, n_type, n, msd): # need the MSD to determine if there is enough area to hold all of the points
    try:

	n = float(n)
        # calc area of layer in acres
	if type == "feature":
	    area = input.area
	else:
	    area = 0
	    rows = gp.SearchCursor(input)    
	    row = rows.Next()
	    while row:
		feat = row.Shape
		area += feat.Area
		row = rows.Next()
	
	if n_type.lower() == "total number of points":
            x = math.floor(n)
	elif n_type.lower() == "points per acre":
            a2 = area / 4046.86
	    x = math.floor(n * a2)
        elif n_type.lower() == "points per hectare":
            a2 = area / 10000.00
	    x = math.floor(n * a2)
	elif n_type.lower() == "1 point per x hectares":
	    a2 = area / 10000.00
	    x = math.floor(a2 / n)
	elif n_type.lower() == "1 point per x acres":
	    a2 = area / 4046.86
	    x = math.floor(a2 / n)	    
	expectArea = math.pow(msd,2) * math.pi * x
	if expectArea > area:
	    gp.AddMessage("Not enough space in the study area to hold all the desired points given the minimum separation distance")
	    return -1
	if x < 1: x = 1
        return x
    except:
	if row:
	    del row
	if rows:
	    del rows
        return -1
    
# ------------------------------------------------------------------------------
# return list of the feature IDs and selection probabilities
# ------------------------------------------------------------------------------
def getIDandProbLists(samp_units, prob_attr):
    try:
	rows = gp.SearchCursor(samp_units)
        row = rows.Next()
    
        # read feature IDs and incl_probs (if prob_attr <> #)
        IDlist = []
        Pi = []
        i = 0
            
        # Get the list of feature IDs and selection probs.
        while row:
	    fid = row.GetValue("FID")
            IDlist.append(fid)
            if not prob_attr == "#":
                f = row.GetValue(prob_attr)
                Pi.append(f)
            row = rows.Next()
            i += 1
    
        del row
        del rows
                
 	return (IDlist, Pi)
    except:
	if row: del row
	if rows: del rows
	return (-1,-1)
    
# ------------------------------------------------------------------------------
# Calculate selection probabilities from lists
# ------------------------------------------------------------------------------
def calcSelProbs(IDlist, Pi, prob_attr):
    try:
	if prob_attr == "#": 
	    Pi = [1.0/len(IDlist)] * len(IDlist) # equal sel probs if no prob attribute stated
	else:
	    # parse the sample probabilities, if they sum to 1, then OK, else, rescale so that they are probabilities
	    sum = 0.0
	    for i in Pi:
		sum += i
		
	    if (sum > 0.99 and sum < 1.01): #good enough
		rescale = False
	    else:  # need to rescale
		rescale = True
	   
	    if rescale:
		temp = []
		for i in Pi:
		    temp.append(i/sum)
		Pi = temp
	return Pi
    except:
	do = "something else"
	return -1
    
# ------------------------------------------------------------------------------
# Create random selections from the ID and sel prob lists
# ------------------------------------------------------------------------------
def selectSamples(prob_attr, c, n):
    try:
	if prob_attr == "#":
	    # lists were shuffled already, just take the first n elements
	    Selected = random.sample(zip(*c)[0],n)
	    selPi = [c[0][1]]*n
	else: # unequal selection prob algorithm from Tille, Y. 2006. Sampling Algorithms. Springer, Inc. New York. page 124.
	    u = random.uniform(0,1)
	    a = -u
	    Selected = []
	    selPi = []
	    
	    for k in c:
		b = a
		a += (k[1] * (int(n)+1))  # k is a tuple. k[1] returns the sample sel. prob from the tuple
		
		if b < 0:
		    bround = math.ceil(b)
		else:
		    bround = math.floor(b)
		if a < 0:
		    around = math.ceil(a)
		else:
		    around = math.floor(a)
		if around <> bround:
		    Selected.append(k[0])
		    selPi.append(k[1])
	return (Selected, selPi)
    except:
	return (-1,-1)

# ------------------------------------------------------------------------------
# Pull random selections out of feature class layer and write to output
# ------------------------------------------------------------------------------
def createSelOutput(Selected, selPi, samp_units, outfeat):
    try:
	# create part of the SQL string from Selected
	l = ""
        for x in Selected:
            l = l + "%s," % str(x)
        l = l[:-1]

	desc = gp.describe(samp_units)
        fields = desc.Fields
        field = fields.next()
        fieldList = ""
        while field:
	    print field.name
	    field = fields.next()
		    
	#sRows = gp.SearchCursor(samp_units)
	#gp.AddMessage("2.1")
	#sRow = sRows.Next()
	#gp.AddMessage("2.2")
	#m = 0
	#while sRow:
	#    print str(sRow.GetValue("POINTID"))
	#    gp.AddMessage("2.3")
	#    sRow = sRows.next()
    
	qstring = ' "FID" IN (%s) ' % l
        gp.MakeFeatureLayer_management(samp_units, "lyr", qstring)
	print " "
	print gp.GetCount_management("lyr")
	
	desc = gp.Describe(samp_units)
	ft = desc.ShapeType
	if (ft=="Point"):
	    gp.CopyFeatures_management("lyr", outfeat)
	else:
	    gp.FeatureToPoint_management("lyr", outfeat, "INSIDE")

	print gp.GetCount_management(outfeat)
	
        #Add X/Y coordinate values to the points
        gp.AddXY_management(outfeat)
        
        #Add the sample probs to the attribute table
        gp.AddField_management(outfeat, "SAMPPROB", "float", "10", "9")
        
        rows = gp.UpdateCursor(outfeat)
        row = rows.Next()
        j = 0
        while row:
            row.SAMPPROB = selPi[j]
            rows.UpdateRow(row)
            row = rows.Next()
            j += 1
        del row
        del rows
	
        # strip out all the other fields        
        desc = gp.describe(outfeat)
        fields = desc.Fields
        field = fields.next()
        fieldList = ""
        while field:
            if not (field.name == "ORIG_FID" or field.name == "POINT_X" or field.name == "POINT_Y" or field.name == "SAMPPROB" or field.name == "FID" or field.name == "Shape"):
                fieldList = fieldList + field.name + ";"
                print(field.name)
            field = fields.next()
	del field
	del fields
	fieldList = fieldList[:-1]
        gp.deleteField_management(outfeat, fieldList)

	return 1
    except:
	if row: del row
	if rows: del rows
	if field: del field
	if fields: del field
	return -1
    
# ------------------------------------------------------------------------------    
# determine if a point is inside a given polygon or not
# Polygon is a list of (x,y) pairs.
# code for this function from Patrick Jordan, http://www.ariel.com.au/a/python-point-int-poly.html
# ------------------------------------------------------------------------------
def point_inside_polygon2(x,y,poly):
    n = len(poly)
    inside =False

    p1x,p1y = poly[0]
    for i in range(n+1):
        p2x,p2y = poly[i % n]
        if y > min(p1y,p2y):
            if y <= max(p1y,p2y):
                if x <= max(p1x,p2x):
                    if p1y != p2y:
                        xinters = (y-p1y)*(p2x-p1x)/(p2y-p1y)+p1x
                    if p1x == p2x or x <= xinters:
                        inside = not inside
        p1x,p1y = p2x,p2y

    return inside

def point_inside_polygon(x,y,layer):
    # 
    pnt = gp.CreateObject("point")
    pnt.x = x
    pnt.y = y
    pntFC = gp.CreateFeatureClass("in_memory", "pnt" "POINT") # create a point feature class
    cur = gp.InsertCursor(pntFC)
    feat = cur.NewRow()
    feat.shape = pnt
    cur.InsertRow(feat)
    del feat
    del cur
    pntLyr = gp.MakeFeatureLayer(pntFC, "pntLyr")
    gp.SelectLayerByLocation(pntLyr, "intersect", layer)
    count = gp.GetCount(pntFC)
    gp.Delete(pntFC)
    if count > 0:
	inside = 1
    else:
	inside = 0
    return inside

# ------------------------------------------------------------------------------
# check if an input point is less than a specified distance from any member of a set of points
# x and y are the coordinates of the point to be evaluated.
# points is a list of point coordinate pairs (x,y)
# d is the minimum separation distance.
# returns true if input point is greater than d from and point, false otherwise
# ------------------------------------------------------------------------------
def point_distance(x,y,points,d):
    n = len(points)
    ok = True
    
    for i in range(n):
	px,py = points[i]	
	dist = math.sqrt(math.pow(y-py,2) + math.pow(x-px,2))
	if dist < d: 
	    ok = False
	    break
	
    return ok

# ------------------------------------------------------------------------------
# dissolve input polygon and return list of X,Y coordinate pairs for the dissolved polygon
# ------------------------------------------------------------------------------
def poly2xylist(layer):
    dissolved = gp.CreateScratchName("xxx", "", "shapefile")
    layercopy = gp.CreateScratchName("xxxx", "", "shapefile")
    gp.MakeFeatureLayer(layer, "layercopy")
    gp.AddField_management("layercopy", "dissolve", "short")
    gp.CalculateField_management("layercopy", "dissolve", "1")
    gp.dissolve_management("layercopy", dissolved, "dissolve")
        
    x = []
    y = []
    rows = gp.SearchCursor(dissolved)
    row = rows.Next()
    while row:
	feat = row.Shape
	part = feat.GetPart(0)
	pnt = part.Next()
	while pnt:
	    x.append(pnt.x)
	    y.append(pnt.y)
	    pnt = part.Next()
	row = rows.Next()
    del row
    del rows
    del feat
    del part
    del pnt
    
    a = zip(x,y)
    
    check_exist(dissolved)
    check_exist(layercopy)
    
    return a

#-------------------------------------------------------------------------------
# convert lots of different linear units to meters
#-------------------------------------------------------------------------------
def convert2meters(x, units):
    if units.lower() == "meters":
	m = x
    elif units.lower() == "centimeters":
	m = x*100
    elif units.lower() == "decimeters":
	m = x*10
    elif units.lower() == "millimeters":
	m = x*1000
    elif units.lower() == "kilometers":
	m = x / 1000.0
    elif units.lower() == "feet":
	m = x / 3.2808399
    elif units.lower() == "miles":
	m = x * 1609.344
    elif units.lower() == "yards":
	m = x * 1.0936133
    elif units.lower() == "inches":
	m = x / 39.3700787
    elif units.lower() == "nautical": #for nautical miles
	m = x * 1852
    elif units.lower() == "points":
	gp.AddMessage("I don't know what points are... Try picking a different distance unit! For now we're going to pretend they're meters")
	m = x
    elif units.lower() == "decimal degrees":
	gp.AddMessage("Please specify a linear distance unit and not an angular one.")
	ReportError("Invalid distance unit")
    elif units.lower() == "unknown":
	gp.AddMessage("Unknown units. Let's pretend they're in meters...")
	m = x

    return m

#-------------------------------------------------------------------------------
# Check to see if a field exists and if it is of the right type
#-------------------------------------------------------------------------------
def CheckField(layer, fName, fType):
    if fType == "numeric":
        qList = ["double", "float", "short", "long", "smallinteger"]
    elif fType == "categorical":
        qList = ["text", "short", "long", "string", "smallinteger"]
    elif fType in ["text", "string"]:
        qList = ["text", "string"]
    else:
        qList = ["text", "date", "double", "short", "long", "float", "blob", "string", "smallinteger"]
    
    fields = gp.listfields(layer)
    fieldName = 0
    fieldType = 0
    for field in fields:
        if field.Name == fName:
            #gp.AddMessage(field.Type.lower())
            if field.Type.lower() in qList: fieldType = 1
            fieldName = 1
            break
    if fieldName and fieldType: 
        out = 1
    else: 
        out = 0
        
    return out


#-------------------------------------------------------------------------------
# Parse a field of an input layer and return a list of unique values
#-------------------------------------------------------------------------------
def getUniqueValues(layer, field):
    rows = gp.SearchCursor(layer)
    row = rows.Next()
    uList = []
    while row:
	e = row.GetValue(field)
	if not e in uList:
	    uList.append(e)
	row = rows.next()
    return uList