#-----------------------------------------------------------------------------
# Name: random_systematic.py
# Author: Jason Karl
# Version: ArcGIS v9.2+
# Date: April 22, 2010
#-----------------------------------------------------------------------------
# Purpose:
# This script draws systematic samples with a randomized start location 
# from within the extent of an input layer. Selection probabilities are equal
# and are calculated from the total number of possible sampling locations.
#-----------------------------------------------------------------------------
# Inputs/Arguments
# extent_layer = feature class specifying extent of sample locations
# msd = minimum distance separating random locations
# n_type = whether minimum distance is maximum plot dimension or some other desired minimum distance
#             valid options are "points per ac", "points per ha", "spacing between points in map units", "total number of points"
# outwork = output workspace where files will be written
# outfeat = name of output point feature class that will contain locations and IDs of the
#           random sample realization.
#-----------------------------------------------------------------------------

#-----------------------------------------------------------------------------
# Libraries & initializaton
#-----------------------------------------------------------------------------
import win32com.client, sys, os, arcgisscripting, math, random
from sample_functions import *
from sample_error_msgs import *
from version_info import *

gp = arcgisscripting.create()

print version_info
gp.AddMessage(version_info)

# read arguments
extent_layer = sys.argv[1]
msd = sys.argv[2]
n_type = sys.argv[3]
outfeat = sys.argv[4]   

try:
    
#-----------------------------------------------------------------------------
# Finish initializing the work environment
#-----------------------------------------------------------------------------

    # load other required toolboxes
    gp.AddToolbox(os.environ['ARCGISHOME']+"ArcToolbox/Toolboxes/Data Management Tools.tbx")
    gp.AddToolbox(os.environ['ARCGISHOME']+"ArcToolbox/Toolboxes/Spatial Analyst Tools.tbx")
    gp.AddToolbox(os.environ['ARCGISHOME']+"ArcToolbox/Toolboxes/Conversion Tools.tbx")    

    
#-----------------------------------------------------------------------------
# validate arguments and initialize
#-----------------------------------------------------------------------------
    gp.AddMessage("Checking arguments")
    print("Checking arguments")

    if extent_layer == "#":
        extent_layer = "C:\\Users\\jasokarl\\Documents\\My Dropbox\\sampling_tools\\d0.shp"
    if not gp.exists(extent_layer):
        raise ReportError, (msgInputDNE + samp_frame)
    # check to see if it is a polygon layer
    desc = gp.Describe(extent_layer)
    st = desc.ShapeType
    if not st.lower() == "polygon": raise ReportError, msgExtentNotPoly
    # check to see if it is projected
    SR = desc.SpatialReference
    if not SR.Type == "Projected": raise ReportError, msgExtentNotProjected

    if msd == "#":
        msd = 100
    
    if n_type == "#":
        n_type = "total number of points"
    if not n_type.lower() in ["points per acre", "points per hectare", "total number of points", "1 point per x acres", "1 point per x hectares", "spacing between points"]:
        raise ReportError, msgInvalidNtype    
    
    if outfeat == "#":
        outfeat = "C:\\Users\\jasokarl\\Documents\\My Dropbox\\sampling_tools\\test_systematic3.shp"
    outwork = os.path.split(outfeat)[0]
    outfeat = os.path.split(outfeat)[1]
    if not os.path.exists(outwork):
        raise ReportError, msgOutPathDNE
        
    #Set workspace
    gp.Workspace = outwork
    gp.OverwriteOutput = True

    # Check output layer and delete if exists
    if not check_exist(outfeat): raise ReportError, msgOutputExists

    print("Creating Sample")
    gp.AddMessage("Creating Sample")
    
#-----------------------------------------------------------------------------
# Get the full extent of the input layer
#-----------------------------------------------------------------------------
    extent = desc.extent
    xmin = float(extent.split(" ")[0])
    ymin = float(extent.split(" ")[1])
    xmax = float(extent.split(" ")[2])
    ymax = float(extent.split(" ")[3])

#-----------------------------------------------------------------------------
# determine point spacing and randomly select start location
#-----------------------------------------------------------------------------
    if n_type == "points per ha":
        msd_inv = 1.0/float(msd) # this gives us how many area units there are per point.
        ha = msd_inv * 10000 # convert to meters (assuming projection units are meters)
        spacing = math.sqrt(ha) # gives spacing between points
    elif n_type == "points per ac":
        msd_inv = 1.0/float(msd) # this gives us how many area units there are per point.
        ha = msd_inv * 4046.86 # convert to meters (assuming projection units are meters)
        spacing = math.sqrt(ha) # gives spacing between points
    elif n_type == "total number of points":
        area = (xmax-xmin)*(ymax-ymin)
        msd_inv = area/float(msd) # in this case msd is number of points
        spacing = math.sqrt(msd_inv) #msd_inv is already in projection units
    elif n_type == "spacing between points":
        spacing = float(msd)
    elif n_type == "1 point per X acres":
        ha = float(msd) * 4046.86
        spacing = math.sqrt(ha)
    elif n_type == "1 point per X hectares":
        ha = float(msd) * 10000
        spacing = math.sqrt(ha)
    else:
        spacing = float(msd)
    
    # do some checking to make sure the spacing is less than the extent
    if spacing >= (xmax - xmin): raise ReportError, msgSpacingTooBig
    if spacing >= (ymax - ymin): raise ReportError, msgSpacingTooBig
        
        
    # get random offsets for starting location
    xoffset = random.uniform(0,spacing)
    yoffset = random.uniform(0,spacing)

    # get start locations
    xstart = xmin + xoffset
    ystart = ymin + yoffset
    
#-----------------------------------------------------------------------------
# Build tuple with point ID, X, Y for all systematic points
#-----------------------------------------------------------------------------
    x = xstart
    y = ystart
    i = 1
    id = []
    xlist = []
    ylist = []
    
    while x < (xmax + xoffset): # adding the offset gives us a little extra room to make sure we go all the way to the extent edge
        while y < (ymax + yoffset):
            id.append(i)
            xlist.append(x)
            ylist.append(y)
            i += 1
            y += spacing
        x += spacing
        y = ystart # need to reset the Y values

    array = zip(id, xlist, ylist)
    selprob = 1/i
            
#-----------------------------------------------------------------------------
# Create output feature class for systematic points
#-----------------------------------------------------------------------------
    scratch_shp = gp.CreateScratchName("xxx", "", "shapefile")
    scratch_shp = os.path.split(scratch_shp)[1]
    if not check_exist(scratch_shp): raise ReportError, msgTempExists
    try:
        gp.CreateFeatureclass(gp.workspace, scratch_shp, "POINT", "#", "#", "#", SR)
        gp.addfield(scratch_shp, "pntID", "SHORT", 8)
        gp.addfield(scratch_shp, "X", "DOUBLE")
        gp.addfield(scratch_shp, "Y", "DOUBLE")
        gp.addfield(scratch_shp, "SelProb", "FLOAT", 10, 9)
        
        tmpDesc = gp.describe(scratch_shp)
        shapefield = tmpDesc.ShapeFieldName
        # create the cursor and objects necessary for the geometry creation
        rows = gp.insertcursor(scratch_shp)
        pnt = gp.createobject("point")
        
        # set iteration over the tuples
        for j in array:
            # for a point feature class simply populate a point object and insert it. 
            row = rows.newrow()
            pnt.id = j[0]
            pnt.x = j[1]
            pnt.y = j[2]
            row.SetValue(shapefield, pnt)
            row.SetValue("pntID", j[0])
            row.SetValue("X", j[1])
            row.SetValue("Y", j[2])
            row.SetValue("SelProb", float(selprob))
            rows.insertrow(row)
        del row
        del rows
        
    except:
        print gp.GetMessages()
        raise ReportError, msgErrorWritingOutput

#-----------------------------------------------------------------------------
# Clip output features to input layer and write final output
#-----------------------------------------------------------------------------
    gp.Clip_analysis(scratch_shp, extent_layer, outfeat)

#-----------------------------------------------------------------------------
# Clean up
#-----------------------------------------------------------------------------
    if not check_exist(scratch_shp): raise ReportError, "Error cleaning up. Can't delete temporary point file."
    print "Finished!"


#-----------------------------------------------------------------------------
# Error Handling
#-----------------------------------------------------------------------------
except ReportError, ErrorMsg: #deals with trapped errors
    gp.AddError(ErrorMsg)
    print ErrorMsg
    gp.AddError("Quitting...")
    print "Quitting..."
except: # deals with untrapped errors 
    gp.AddMessage(gp.GetMessages(2))
    print(gp.GetMessages(2))
