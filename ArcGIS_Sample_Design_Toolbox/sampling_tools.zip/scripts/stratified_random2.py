#-----------------------------------------------------------------------------
# Name: stratified_random.py
# Author: Jason Karl
# Version: ArcGIS v9.2+
# Date: April 26, 2010
#-----------------------------------------------------------------------------
# Purpose:
# This script creates a set of stratified random points from within an input layers' extent according to
# the following properties:
# 1. selection probabilities are equal
# 2. strata are defined by an attribute in the polygon input layer. points will be randomly generated within each
#    polygon of the stratum layer.
# 3. procedure follows simple random selection within each stratum
# 4. minimum distance separating locations can be specified
# 5. A fixed number of points per stratum can be defined, or the number can vary by stratum
# 4. number of samples per stratum can be specified in absolute terms or as a density
#-----------------------------------------------------------------------------
# Inputs/Arguments
# stratum_layer = feature class specifying extent of sample locations
# stratum_field = field of the input feature set that defines the strata
# distunits = minimum distance separating random locations
# fixed_or_variable = will a fixed number of samples be drawn from each stratum, or will it vary by stratum?
# n = number of samples desired. Conitional on fixed
# n_field = field of the input polygon feature class that defines how many samples will be drawn per stratum.
#           Conditional on variable.
# n_type = whether n is expressed in absolute terms or as a density in # per ac or # per ha.
#          acceptable values are: "Absolute", "Density per hectare", and "Density per acre."
# outfeat = name of output point feature class that will contain locations and IDs of the
#           random sample realization.
#-----------------------------------------------------------------------------

#-----------------------------------------------------------------------------
# Libraries & initializaton
#-----------------------------------------------------------------------------
import sys, os, arcgisscripting, math, random, time
from sample_functions import *
from sample_error_msgs import *
from version_info import *

gp = arcgisscripting.create()

print version_info
gp.AddMessage(version_info)

# read arguments
stratum_fs = gp.GetParameter(0)
stratum_field = sys.argv[2]
distunits = sys.argv[3]
fixed_or_variable = sys.argv[4]
n = sys.argv[5]
n_field = sys.argv[6]
n_type = sys.argv[7]
outfeat = sys.argv[8]   




try:
    
#-----------------------------------------------------------------------------
# Finish initializing the work environment
#-----------------------------------------------------------------------------

    # load other required toolboxes
    #check version and get install directory
    installD = gp.GetInstallInfo("desktop")
    for key in installD.keys():
        if key == "InstallDir":
            installpath = installD[key]   
    
    # load other required toolboxes
    gp.AddToolbox(installpath+"ArcToolbox\\Toolboxes\\Data Management Tools.tbx")
    gp.AddToolbox(installpath+"ArcToolbox\\Toolboxes\\Conversion Tools.tbx")  
    
#-----------------------------------------------------------------------------
# validate arguments and initialize
#-----------------------------------------------------------------------------
    gp.AddMessage("Checking arguments")
    print("Checking arguments")

    if stratum_fs == "#":
        stratum_fs = "C:\\Users\\Jason\\Documents\\Multi_Scale_Assessment\\analysis\\\Castle_Creek_Study_Design\\scale100b.shp"
    if not gp.exists(stratum_fs):
        raise ReportError, (msgInputDNE + stratum_fs)
    # check to see if it is a polygon layer
    desc = gp.Describe(stratum_fs)
    st = desc.ShapeType
    if not st.lower() == "polygon": raise ReportError, msgExtentNotPoly
    # check to see if it is projected
    SR = desc.SpatialReference
    if not SR.Type == "Projected": raise ReportError, msgExtentNotProjected

    # check to see if the stratum_field exists
    if stratum_field == "#":
        stratum_field = "iObj100ID"
    # check to see if attribute exists and that it's numeric
    if not CheckField(stratum_fs, stratum_field, "categorical"): raise ReportError, msgAttributeDNE    
    
    # parse out the distance from the units and convert to meters
    if distunits == "#":
        distunits = "200 Meters"
    h = distunits.split()
    dist = float(h[0])
    units = h[1]
    msd = convert2meters(dist,units)
    
    # check the sample size arguments
    if fixed_or_variable.lower() == "#": fixed_or_variable = "variable"
    if fixed_or_variable.lower() == "fixed":
        if n == "#": n = float(500)
        else: float(n)
    else:
        if n_field == "#": n_field = "numpoints"
        if not CheckField(stratum_fs, n_field, "numeric"): raise ReportError, msgAttributeDNE
    
    # check the sample size type argument
    if n_type == "#":
        n_type = "total number of points"
    if not n_type.lower() in ["points per acre", "points per hectare", "total number of points", "1 point per x acres", "1 point per x hectares"]:
        raise ReportError, msgInvalidNtype
    
    # get the output feature class name and directory
    if outfeat == "#":
        outfeat = "C:\\Users\\Jason\\Dropbox\\sampling_tools\\test_stratrs11.shp"
    outwork = os.path.split(outfeat)[0]
    outfeat = os.path.split(outfeat)[1]
    if not os.path.exists(outwork):
        raise ReportError, msgOutPathDNE
        
    #Set workspace
    gp.Workspace = outwork
    gp.OverwriteOutput = True

    # Check output layer and delete if exists
    if not check_exist(outfeat): raise ReportError, msgOutputExists

    
    print("Creating Sample")
    gp.AddMessage("Creating Sample")
#-----------------------------------------------------------------------------
# Dissolve the stratum layer by the stratum field, then start iteration over strata
#-----------------------------------------------------------------------------

    sRows = gp.SearchCursor(stratum_fs)
    sRow = sRows.Next()
    m = 0
    while sRow:
        s = sRow.shape
        stratum = sRow.GetValue(stratum_field)
        if fixed_or_variable.lower() == "variable":
            n = sRow.GetValue(n_field)
        m += 1

#-----------------------------------------------------------------------------
# figure out how many samples are needed and check to see if they'll fit in the extent polygon
#-----------------------------------------------------------------------------
        n2 = calc_num_samps(s, "feature", n_type, float(n), msd)
        if n2 == -1: raise ReportError, msgSampSizeError
        
#-----------------------------------------------------------------------------
# Create random locations
#-----------------------------------------------------------------------------
        try:
            randPts = gp.CreateRandomPoints("in_memory", "randPts", s, "", n2, msd)
            #gp.AddField(randPts, "Stratum", "TEXT")
            #gp.CalculateField_management(randPts, "Stratum", 'stratum')
            
            if m == 1:
                gp.CopyFeatures_management(randPts, "in_memory\\hold")
            else:
                gp.Append_management(randPts, hold)
            gp.Delete_management(randPts)
        except:
            print gp.GetMessages()
            raise ReportError, msgErrorWritingOutput
    
        sRow = sRows.Next()
    del sRow
    del sRows

#-----------------------------------------------------------------------------
# Create output feature class for systematic points
#-----------------------------------------------------------------------------
    gp.CopyFeatures_management(hold, outfeat)
    try:
        gp.addfield(outfeat, "pntID", "SHORT", 8)
        gp.addxy(outfeat)
        gp.addfield(outfeat, "SelProb", "FLOAT", 10, 9)
        gp.CalculateField_management(outfeat, "pntID", "[FID] + 1")
        Ninv = 1 / gp.GetCount(outfeat)
        gp.CalculateField_management(outfeat, "SelProb", Ninv)
        
    except:
        print gp.GetMessages()
        raise ReportError, msgErrorWritingOutput    
    
#-----------------------------------------------------------------------------
# Clean up
#-----------------------------------------------------------------------------
    print "Finished!"


#-----------------------------------------------------------------------------
# Error Handling
#-----------------------------------------------------------------------------
except ReportError, ErrorMsg: #deals with trapped errors
    gp.AddError(ErrorMsg)
    print ErrorMsg
    gp.AddError("Quitting...")
    print "Quitting..."
except: # deals with untrapped errors
    gp.AddMessage(gp.GetMessages(2))
    print(gp.GetMessages(2))
