import arcpy

layerString = arcpy.GetParameterAsText(0)
desc = arcpy.Describe(layerString)
extent = desc.extent
out = "%s %f, %s %f, %s %f, %s %f" % ("Xmin", extent.XMin, "Ymin", extent.YMin, "Xmax", extent.XMax, "Ymax", extent.YMax)

arcpy.SetParameterAsText(1,out)
arcpy.AddMessage(out)